<?php

class MySQLDB {
    private $defaultDebug = false;
    private $mtStart;
    private $nbQueries;
    private $lastResult;
    private $connect;
    private $statement;

	public function __construct( $siteID='liwa05', $charset='utf8mb4' ) {
		$data=file_get_contents('/api/json/'.$siteID.'.json');
		$arrParam = json_decode($data, true);
		$siteID = $arrParam['siteID'];
		$DBName = $arrParam['DBName'];
		$DBUser = $arrParam['DBUser'];
		$DBPswd = $arrParam['DBPswd'];	
		$DBHost = $arrParam['DBHost'];
		try {
			$this->connect = new PDO("mysql:host=".$DBHost.";dbname=".$DBName."; charset=".$charset, $DBUser, $DBPswd, array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8")); 		
			$this->connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
		}
		catch(PDOException $e) {
			// echo "ERROR : ".$e->getMessage();
			$this->connect = null;
		}
		return $this->connect;	
	}

	function __destruct(){
		$this->connect = null;
	}

	public function query ( $query , $debug = -1 ){
		$this->lastResult = $this->connect->query( $query );
		return $this->lastResult;
	}

	public function exec( $query, $debug = -1) {
		$this->lastResult = $this->connect->exec( $query );
		return $this->lastResult;
	}

	public function fetchDataArray ($result = NULL){
		if ($result == NULL ){
			return NULL;
		}else{
			$i=0;
			$data = array();
			$rows = $result->fetchAll(PDO::FETCH_ASSOC);
			foreach ($rows as $row) {
				foreach ($row as $key => $value) {
					$data[$i][$key] = $value;
				}
				$i++;
			}
			return $data;
		}
	}

	public function fetchFieldsNums($result){
		if ($result == NULL) {
			return NULL;
		} else {
			return $result->columnCount();
		}
	}

	public function queryNumRows($result){
		$rowNum = $result->rowCount();
		return $rowNum;
	}

	public function queryUniqueValue($result){
		$rows = $result->fetch(PDO::FETCH_NUM);
		return $rows[0];
	}

	public function queryUniqueRow($result){
		$rows = $result->fetch(PDO::FETCH_NUM);
		return $rows;
	}

	public function free(){
		//$this->lastResult->free_result();
	}

	public function close(){
		// $this->connect->close();
		$this->connect = null;
	}

	public function errorInfo() {
		return $this->connect->errorInfo();
	}

}

?>
