<?php
include_once('UUID.php');
date_default_timezone_set("Asia/Taipei");
defined('DS') ? NULL: define('DS', DIRECTORY_SEPARATOR);

function bMoveFile($tmpname, $filename, $boverwrite)
{
	// set up the directory of uploaded file
	$uploadpath = 'images'.DS;
	if (($boverwrite = false) && (file_exist($uploadpath.$filename))) 
	{
		return false;
	}
	else
	{
		move_uploaded_file($tmpname, $uploadpath.$filename);
		return true;
	}
}

function full_move($src, $dst){
    full_copy($src, $dst);
    full_remove($src);
}

function full_copy($src, $dst) {
    if (is_dir($src)) {
        @mkdir( $dst, 0777 ,TRUE);
        $files = scandir($src);
        foreach($files as $file){
            if ($file != "." && $file != ".."){
                full_copy("$src".DS."$file", "$dst".DS."$file");
            }
        }
    } else if (file_exists($src)){
        copy($src, $dst);
    }
}

function full_remove($dir) {
    if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file){
            if ($file != "." && $file != ".."){
                full_remove("$dir".DS."$file");
            }
        }
        rmdir($dir);
    }else if (file_exists($dir)){
        unlink($dir);
    }
}

function full_chmod($path, $filePerm=0644, $dirPerm=0777) {
	// check if the path exists
	if (!file_exists($path)) {
		return false;
	}

	// see whether this is a file
	if (is_file($path)) {
		chmod($path, $filePerm);
	} elseif (is_dir($path)){
		// If this is a directory, get an array of the contents
		$foldersAndFiles = scandir($path);
		// remove "." and ".." from the list
		$entries = array_slice($foldersAndFiles, 2);
		// parse every result
		foreach($entries as $entry){
			full_chmod($path.'/'.$entry, $filePerm, $dirPerm);
		}
		// chmod itself
		chmod($path, $dirPerm);
	}
	return true;
}

function fail($message) {
		header("Content-Type:text/html; charset=utf-8");
		die(json_encode(array('status' => 'fail', 'message' => $message), JSON_UNESCAPED_UNICODE));
	}

function success($message, $key) {
		header("Content-Type:text/html; charset=utf-8");
		die(json_encode(array('status' => 'success', 'message' => $message, 'key'=>$key), JSON_UNESCAPED_UNICODE));
		// 
	}
	
function continu($message) {
		die(json_encode(array('status' => 'continue', 'message' => $message)));
	}
	
function getNewFileName($fname) {
	$File_Name          = $fname;
	$File_Ext           = substr($File_Name, strrpos($File_Name, '.')); //get file extention
	$Random_Number      = rand(0, 9999999999); //Random number to be added to name.
	$NewFileName 		= $Random_Number.$File_Ext; //new file name
	//$NewFileName   		= "_".$File_Name.$File_Ext;     // new file name
	return $NewFileName;
}

function saveLog($arrData, $hostIP){
	$ch = curl_init();
	$url = "http://".$hostIP."/liwa05/php/sys_addLog.php";
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, 1);	
	curl_setopt($ch, CURLOPT_POSTFIELDS, $arrData);
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}	

function increaseID($maxID, $start, $HeadLen)
{
	$iTotalLen = strlen($maxID);
	$iRestLen = $iTotalLen - $HeadLen; 
	$ID_Head = substr($maxID,$start,$HeadLen);
	$New_ID = substr($maxID,$HeadLen,$iRestLen);
	$iLen = strlen($New_ID);
	$New_ID = $New_ID * 1;
	$New_ID ++;
	$tempCount = strlen($New_ID);
	if ( $tempCount < $iLen) {
		$zeroCount = $iLen - $tempCount;
		for($i=0; $i<$zeroCount; $i++)
			$New_ID = '0'.$New_ID;
	}
	$New_ID = $ID_Head.$New_ID;
	return $New_ID;
}

// change yyyymmdd format of date
function convertDate($str) {
	$year = substr($str, 0, 4);
	$month = substr($str, 5, 2);
	$day = substr($str, 8, 2);
	$AA = $year.$month.$day;
	return $AA;
}

function millDate() {
	$AA = date('Y/m/d H:i:s.') . gettimeofday()['usec'];
	return $AA;
}

function writUserLog($sMsg, $webID, $iMode=1){
	// $iMode == 0 =>系統模組; $iMode==1 => 非系統模組
	$path = ($iMode == 0)? "../archive/".$webID."/log/": "../../archive/".$webID."/log/";
	$sTime = date("Y/m/d H:i:s");
	$fp = fopen($path."syslog.txt", "a");
	$userLog = $sTime." - ".$sMsg.PHP_EOL;
	fwrite($fp, $userLog);
	fclose($fp);	
}

function writSysLog($sMsg){
	$sTime = date("Y/m/d H:i:s");
	$fp = fopen("../logs/syslog.txt", "a");
	$userLog = $sTime." - ".$sMsg.PHP_EOL;
	fwrite($fp, $userLog);
	fclose($fp);	
}

function getClientIP(){
	// must php 5.3+ version
	$ip = getenv('HTTP_CLIENT_IP')?:
	getenv('HTTP_X_FORWARDED_FOR')?:
	getenv('HTTP_X_FORWARDED')?:
	getenv('HTTP_FORWARDED_FOR')?:
	getenv('HTTP_FORWARDED')?:
	getenv('REMOTE_ADDR');

	return $ip;
}  

function getUUID($i = 5){
	$iRand = rand(0, 9);
	//$strDate = date('YmdHis').$i;
	$strDate = date('YmdHis').$iRand;
	$v3uuid = UUID::v3('1546058f-5a25-4334-85ae-e68f2a44bbaf', $strDate);

	return $v3uuid;
}

function getRanCode($iLen){
	$strBase = "abcdefghijklmnopqrstuvwxyz0123456789";
	$AA = "";
	for ($i==0; $i<$iLen; $i++) {
			$iPos = rand(0, 35);
			$strTemp = substr($strBase, $iPos, 1);
			$AA .= $strTemp;
	}	
	return $AA;
}

function getInviteCode($sID) {
	// generate inviteCode
	$iPos = rand(0,9);
	$preStr = getRanCode($iPos);
	$endStr = getRanCode(2);
	$iLength = 30-1-6-2-$iPos;
	$postStr = getRanCode($iLength);
	$inviteCode = $preStr.$sID.$postStr.$iPos.$endStr;		

	return $inviteCode;
}

function parseInviteCode($sID) {
	// check $sID.length == 30
	$codeLength = strlen($sID);
	if ($codeLength !== 30) {
		$nuID = "";
	} else {
		$iPos = substr($sID, 27, 1);
		$iPos = $iPos * 1;
		$nuID = substr($sID, $iPos, 6);	
	}		

	return $nuID;
}

function getIDCode($sID, $iIDLen) {
	// generate inviteCode
	$iPos = rand(0,9);
	$preStr = getRanCode($iPos);
	$endStr = getRanCode(2);
	$iLength = 30-1-$iIDLen-2-$iPos;
	$postStr = getRanCode($iLength);
	$IDCode = $preStr.$sID.$postStr.$iPos.$endStr;		

	return $IDCode;
}

function getDateShift($sDate, $strDiff, $dateUnit=' day') {
	// usage: getDateSwift('2018/08/27', '+7');
	$nuDate = date('Y/m/d', strtotime($strDiff.$dateUnit, strtotime($sDate)));
	return $nuDate;
}

function parseIDCode($sID, $iIDLen) {
	// check $sID.length == 30
	$codeLength = strlen($sID);
	if ($codeLength !== 30) {
		$nuID = "";
	} else {
		$iPos = substr($sID, 27, 1);
		$iPos = $iPos * 1;
		$nuID = substr($sID, $iPos, $iIDLen);	
	}		

	return $nuID;
}

function replaceNulltoEmptyStr($array)
{
    foreach ($array as $key => $value) 
    {
        if(is_array($value))
            $array[$key] = replaceNulltoEmptyStr($value);
        else
        {
            if (is_null($value))
                $array[$key] = "";
        }
    }
    return $array;
}

// system message functions
function getSysMsg($key, $str1, $iMode=0) {
	$path = ($iMode == 0)? "../json/": "../../json/";
	$data = file_get_contents($path.'msgDlg.json');
	$arrData = json_decode($data, true);
	$msgTmp = $arrData[$key];
	$msg = ($str1)?str_replace('@@', $str1, $msgTmp): $msgTmp;
	unset($data);
	unset($arrData);
	return $msg;
}

function getJSONMsg($fileName, $key, $str1='') {
	$data = file_get_contents($fileName);
	$arrData = json_decode($data, true);
	$msgTmp = $arrData[$key];
	$msg = ($str1)?str_replace('@@', $str1, $msgTmp): $msgTmp;
	unset($data);
	unset($arrData);	
	return $msg;
}

function setJSONMsg($fileName, $key, $msg) {
	$data = file_get_contents($fileName);
	$arrData = json_decode($data, true);
	if (array_key_exists($key, $arrData)) {
		unset($arrData[$key]);
	}
	$arrData[$key] = $msg;
	$output = json_encode($arrData, JSON_UNESCAPED_UNICODE);	
	file_put_contents($fileName, $output);
	return $key;
}

function delJSONMsg($fileName, $key) {
	$data = file_get_contents($fileName);
	$arrData = json_decode($data, true);
	if (array_key_exists($key, $arrData)) {
		unset($arrData[$key]);
	}
	$output = json_encode($arrData, JSON_UNESCAPED_UNICODE);	
	file_put_contents($fileName, $output);		
}

// pic process functions
function imgScale($file, $w, $h, $nuFile, $crop=FALSE) {
	// $nuFile 必須為全路徑
	$iStrlen = strlen($file);
	$ext = substr($file, $iStrlen-3, 3);
	
	// get width & height of pic
	list($width, $height) = getimagesize($file);
    $r = $width / $height;
    if ($crop) {
        if ($width > $height) {
            $width = ceil($width-($width*abs($r-$w/$h)));
        } else {
            $height = ceil($height-($height*abs($r-$w/$h)));
        }
        $newwidth = $w;
        $newheight = $h;
    } else {
        if ($w/$h > $r) {
            $newwidth = $h*$r;
            $newheight = $h;
        } else {
            $newheight = $w/$r;
            $newwidth = $w;
        }
    }
	
	$nuFileName = $nuFile.".png";

	switch ($ext)
	{
		case 'jpg':
			$src = imagecreatefromjpeg($file);
			$dst = imagecreatetruecolor($newwidth, $newheight);
			imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);	
			break;
		case 'png':
			$src = imagecreatefrompng($file);
			$dst = imagecreatetruecolor($newwidth, $newheight);
			imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);	
			break;
		case 'gif':
			$src = imagecreatefromgif($file);
			$dst = imagecreatetruecolor($newwidth, $newheight);
			imagecopyresampled($dst, $src, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);	
			break;
	}
	imagepng($dst, $nuFileName);
	imagedestroy($dst);
	// png format only
	$dstFile = $nuFile.".png";    

    return $dstFile;
}

function imageSave($base64, $sName, $iDstWidth, $iMode) {
	$sType = substr($base64, 11, 3);
	if (($sType == 'jpe') || ($sType == 'jpg')) {
		$img = imagecreatefromjpeg($base64);
	} else {
		$img = imagecreatefrompng($base64);
	}
	
	$AA = '';
	if ($img) {
		$width = imagesx($img);
		$height = imagesy($img);
		$ratio = $height/$width;
		$width1 = $iDstWidth;
		if ($iMode == 0) {
			// width == height
			$ratio = 1;
		} 
		$height1 = $iDstWidth * $ratio;
			
		$dst = imagecreatetruecolor($width1, $height1);
		
		imagecopyresized($dst, $img, 0, 0, 0, 0, $width1, $height1, $width, $height);
		imagepng($dst, $sName);
		chmod($sName, 0777);
		$AA = $sName;
	}
	return $AA;
}

function barcode( $text="0", $size="20", $orientation="horizontal", $code_type="code128", $print=false, $SizeFactor=1 ) 
{
	// generate barcode and convert output to base64
	$code_string = "";
	// Translate the $text into barcode the correct $code_type
	if ( in_array(strtolower($code_type), array("code128", "code128b")) ) {
		$chksum = 104;
		// Must not change order of array elements as the checksum depends on the array's key to validate final code
		$code_array = array(" "=>"212222","!"=>"222122","\""=>"222221","#"=>"121223","$"=>"121322","%"=>"131222","&"=>"122213","'"=>"122312","("=>"132212",")"=>"221213","*"=>"221312","+"=>"231212",","=>"112232","-"=>"122132","."=>"122231","/"=>"113222","0"=>"123122","1"=>"123221","2"=>"223211","3"=>"221132","4"=>"221231","5"=>"213212","6"=>"223112","7"=>"312131","8"=>"311222","9"=>"321122",":"=>"321221",";"=>"312212","<"=>"322112","="=>"322211",">"=>"212123","?"=>"212321","@"=>"232121","A"=>"111323","B"=>"131123","C"=>"131321","D"=>"112313","E"=>"132113","F"=>"132311","G"=>"211313","H"=>"231113","I"=>"231311","J"=>"112133","K"=>"112331","L"=>"132131","M"=>"113123","N"=>"113321","O"=>"133121","P"=>"313121","Q"=>"211331","R"=>"231131","S"=>"213113","T"=>"213311","U"=>"213131","V"=>"311123","W"=>"311321","X"=>"331121","Y"=>"312113","Z"=>"312311","["=>"332111","\\"=>"314111","]"=>"221411","^"=>"431111","_"=>"111224","\`"=>"111422","a"=>"121124","b"=>"121421","c"=>"141122","d"=>"141221","e"=>"112214","f"=>"112412","g"=>"122114","h"=>"122411","i"=>"142112","j"=>"142211","k"=>"241211","l"=>"221114","m"=>"413111","n"=>"241112","o"=>"134111","p"=>"111242","q"=>"121142","r"=>"121241","s"=>"114212","t"=>"124112","u"=>"124211","v"=>"411212","w"=>"421112","x"=>"421211","y"=>"212141","z"=>"214121","{"=>"412121","|"=>"111143","}"=>"111341","~"=>"131141","DEL"=>"114113","FNC 3"=>"114311","FNC 2"=>"411113","SHIFT"=>"411311","CODE C"=>"113141","FNC 4"=>"114131","CODE A"=>"311141","FNC 1"=>"411131","Start A"=>"211412","Start B"=>"211214","Start C"=>"211232","Stop"=>"2331112");
		$code_keys = array_keys($code_array);
		$code_values = array_flip($code_keys);
		for ( $X = 1; $X <= strlen($text); $X++ ) {
			$activeKey = substr( $text, ($X-1), 1);
			$code_string .= $code_array[$activeKey];
			$chksum=($chksum + ($code_values[$activeKey] * $X));
		}
		$code_string .= $code_array[$code_keys[($chksum - (intval($chksum / 103) * 103))]];

		$code_string = "211214" . $code_string . "2331112";
	} elseif ( strtolower($code_type) == "code128a" ) {
		$chksum = 103;
		$text = strtoupper($text); // Code 128A doesn't support lower case
		// Must not change order of array elements as the checksum depends on the array's key to validate final code
		$code_array = array(" "=>"212222","!"=>"222122","\""=>"222221","#"=>"121223","$"=>"121322","%"=>"131222","&"=>"122213","'"=>"122312","("=>"132212",")"=>"221213","*"=>"221312","+"=>"231212",","=>"112232","-"=>"122132","."=>"122231","/"=>"113222","0"=>"123122","1"=>"123221","2"=>"223211","3"=>"221132","4"=>"221231","5"=>"213212","6"=>"223112","7"=>"312131","8"=>"311222","9"=>"321122",":"=>"321221",";"=>"312212","<"=>"322112","="=>"322211",">"=>"212123","?"=>"212321","@"=>"232121","A"=>"111323","B"=>"131123","C"=>"131321","D"=>"112313","E"=>"132113","F"=>"132311","G"=>"211313","H"=>"231113","I"=>"231311","J"=>"112133","K"=>"112331","L"=>"132131","M"=>"113123","N"=>"113321","O"=>"133121","P"=>"313121","Q"=>"211331","R"=>"231131","S"=>"213113","T"=>"213311","U"=>"213131","V"=>"311123","W"=>"311321","X"=>"331121","Y"=>"312113","Z"=>"312311","["=>"332111","\\"=>"314111","]"=>"221411","^"=>"431111","_"=>"111224","NUL"=>"111422","SOH"=>"121124","STX"=>"121421","ETX"=>"141122","EOT"=>"141221","ENQ"=>"112214","ACK"=>"112412","BEL"=>"122114","BS"=>"122411","HT"=>"142112","LF"=>"142211","VT"=>"241211","FF"=>"221114","CR"=>"413111","SO"=>"241112","SI"=>"134111","DLE"=>"111242","DC1"=>"121142","DC2"=>"121241","DC3"=>"114212","DC4"=>"124112","NAK"=>"124211","SYN"=>"411212","ETB"=>"421112","CAN"=>"421211","EM"=>"212141","SUB"=>"214121","ESC"=>"412121","FS"=>"111143","GS"=>"111341","RS"=>"131141","US"=>"114113","FNC 3"=>"114311","FNC 2"=>"411113","SHIFT"=>"411311","CODE C"=>"113141","CODE B"=>"114131","FNC 4"=>"311141","FNC 1"=>"411131","Start A"=>"211412","Start B"=>"211214","Start C"=>"211232","Stop"=>"2331112");
		$code_keys = array_keys($code_array);
		$code_values = array_flip($code_keys);
		for ( $X = 1; $X <= strlen($text); $X++ ) {
			$activeKey = substr( $text, ($X-1), 1);
			$code_string .= $code_array[$activeKey];
			$chksum=($chksum + ($code_values[$activeKey] * $X));
		}
		$code_string .= $code_array[$code_keys[($chksum - (intval($chksum / 103) * 103))]];

		$code_string = "211412" . $code_string . "2331112";
	} elseif ( strtolower($code_type) == "code39" ) {
		$code_array = array("0"=>"111221211","1"=>"211211112","2"=>"112211112","3"=>"212211111","4"=>"111221112","5"=>"211221111","6"=>"112221111","7"=>"111211212","8"=>"211211211","9"=>"112211211","A"=>"211112112","B"=>"112112112","C"=>"212112111","D"=>"111122112","E"=>"211122111","F"=>"112122111","G"=>"111112212","H"=>"211112211","I"=>"112112211","J"=>"111122211","K"=>"211111122","L"=>"112111122","M"=>"212111121","N"=>"111121122","O"=>"211121121","P"=>"112121121","Q"=>"111111222","R"=>"211111221","S"=>"112111221","T"=>"111121221","U"=>"221111112","V"=>"122111112","W"=>"222111111","X"=>"121121112","Y"=>"221121111","Z"=>"122121111","-"=>"121111212","."=>"221111211"," "=>"122111211","$"=>"121212111","/"=>"121211121","+"=>"121112121","%"=>"111212121","*"=>"121121211");

		// Convert to uppercase
		$upper_text = strtoupper($text);

		for ( $X = 1; $X<=strlen($upper_text); $X++ ) {
			$code_string .= $code_array[substr( $upper_text, ($X-1), 1)] . "1";
		}

		$code_string = "1211212111" . $code_string . "121121211";
	} elseif ( strtolower($code_type) == "code25" ) {
		$code_array1 = array("1","2","3","4","5","6","7","8","9","0");
		$code_array2 = array("3-1-1-1-3","1-3-1-1-3","3-3-1-1-1","1-1-3-1-3","3-1-3-1-1","1-3-3-1-1","1-1-1-3-3","3-1-1-3-1","1-3-1-3-1","1-1-3-3-1");

		for ( $X = 1; $X <= strlen($text); $X++ ) {
			for ( $Y = 0; $Y < count($code_array1); $Y++ ) {
				if ( substr($text, ($X-1), 1) == $code_array1[$Y] )
					$temp[$X] = $code_array2[$Y];
			}
		}

		for ( $X=1; $X<=strlen($text); $X+=2 ) {
			if ( isset($temp[$X]) && isset($temp[($X + 1)]) ) {
				$temp1 = explode( "-", $temp[$X] );
				$temp2 = explode( "-", $temp[($X + 1)] );
				for ( $Y = 0; $Y < count($temp1); $Y++ )
					$code_string .= $temp1[$Y] . $temp2[$Y];
			}
		}

		$code_string = "1111" . $code_string . "311";
	} elseif ( strtolower($code_type) == "codabar" ) {
		$code_array1 = array("1","2","3","4","5","6","7","8","9","0","-","$",":","/",".","+","A","B","C","D");
		$code_array2 = array("1111221","1112112","2211111","1121121","2111121","1211112","1211211","1221111","2112111","1111122","1112211","1122111","2111212","2121112","2121211","1121212","1122121","1212112","1112122","1112221");

		// Convert to uppercase
		$upper_text = strtoupper($text);

		for ( $X = 1; $X<=strlen($upper_text); $X++ ) {
			for ( $Y = 0; $Y<count($code_array1); $Y++ ) {
				if ( substr($upper_text, ($X-1), 1) == $code_array1[$Y] )
					$code_string .= $code_array2[$Y] . "1";
			}
		}
		$code_string = "11221211" . $code_string . "1122121";
	}

	// Pad the edges of the barcode
	$code_length = 20;
	if ($print) {
		$text_height = 30;
	} else {
		$text_height = 0;
	}
	
	for ( $i=1; $i <= strlen($code_string); $i++ ){
		$code_length = $code_length + (integer)(substr($code_string,($i-1),1));
        }

	if ( strtolower($orientation) == "horizontal" ) {
		$img_width = $code_length*$SizeFactor;
		$img_height = $size;
	} else {
		$img_width = $size;
		$img_height = $code_length*$SizeFactor;
	}

	$image = imagecreate($img_width, $img_height + $text_height);
	$black = imagecolorallocate ($image, 0, 0, 0);
	$white = imagecolorallocate ($image, 255, 255, 255);

	imagefill( $image, 0, 0, $white );
	if ( $print ) {
		imagestring($image, 5, 31, $img_height, $text, $black );
	}

	$location = 10;
	for ( $position = 1 ; $position <= strlen($code_string); $position++ ) {
		$cur_size = $location + ( substr($code_string, ($position-1), 1) );
		if ( strtolower($orientation) == "horizontal" )
			imagefilledrectangle( $image, $location*$SizeFactor, 0, $cur_size*$SizeFactor, $img_height, ($position % 2 == 0 ? $white : $black) );
		else
			imagefilledrectangle( $image, 0, $location*$SizeFactor, $img_width, $cur_size*$SizeFactor, ($position % 2 == 0 ? $white : $black) );
		$location = $cur_size;
	}
	
	ob_start();
	imagepng($image);
	$contents = ob_get_contents();
	imagedestroy($image);
	ob_end_clean();
	
	$sBaseUri = "data:image/png;base64," . base64_encode($contents);
	
	return $sBaseUri;
}

function addFolderToZip($dir, $zipArchive, $zipdir = ''){
	// $dir must end with "/"
	// $zipdir is the customerized folder name in ziparchive
    if (is_dir($dir)) {
        if ($dh = opendir($dir)) {

            //Add the directory
            if(!empty($zipdir)) $zipArchive->addEmptyDir($zipdir);
          
            // Loop through all the files
            while (($file = readdir($dh)) !== false) {
          
                //If it's a folder, run the function again!
                if(!is_file($dir.$file)){
                    // Skip parent and root directories
                    if( ($file !== ".") && ($file !== "..")){
                        addFolderToZip($dir.$file."/", $zipArchive, $zipdir.$file."/");
                    }
                  
                }else{
                    // Add the files
                    $zipArchive->addFile($dir . $file, $zipdir . $file);
                }
            }
        }
    }
} 

function checkDuplicate($arrParam, $webID, $DB, $tblName) {
	$DonDel = $arrParam['onDel'];	
	$Dpath = $arrParam['path']; 	 // 目標路徑
	$DfileNameTmp = $arrParam['fileName'];
	
	list($progID, $sDetail) = explode('_', $tblName);	
	// 判斷為 _M or _D1
	$iType = ($sDetail == 'M')? 0: 1;
	
	if ($iType == 1) {
		//$sMainName = pathinfo($DfileNameTmp, PATHINFO_BASENAME);
		//$baseNameTmp = substr($sMainName, 0, -4);
		$baseNameTmp = substr($DfileNameTmp, 0, -4);
		$sExt = pathinfo($DfileNameTmp, PATHINFO_EXTENSION); 
		
		list($baseName, $tmpstr) = explode('(', $baseNameTmp);
	} else {
		list($DfileName, $tmpstr) = explode('(', $DfileNameTmp);
	} 
	if ($progID == 'A05') {
		if ($DonDel == 0) {
			$WorkingDir = ($Dpath == '/')?'..'.DS.'archive'.DS.$webID.DS.'img'.$Dpath:'..'.DS.'archive'.DS.$webID.DS.'img'.$Dpath.DS;
		} else {
			$WorkingDir = ($Dpath == '/')?'..'.DS.'archive'.DS.$webID.DS.'Trash_imgs'.$Dpath: '..'.DS.'archive'.DS.$webID.DS.'Trash_imgs'.$Dpath.DS;
		}
	} else {
		if ($DonDel == 0) {
			$WorkingDir = ($Dpath == '/')?'..'.DS.'archive'.DS.$webID.$Dpath: '..'.DS.'archive'.DS.$webID.$Dpath.DS;
		} else {
			$WorkingDir = ($Dpath == '/')?'..'.DS.'archive'.DS.$webID.DS.'Trash_files'.$Dpath: '..'.DS.'archive'.DS.$webID.DS.'Trash_files'.$Dpath.DS;
		}
	}

	$oldPath = getcwd();
	chdir($WorkingDir);
	$iFolderLen = 0;
	$bSrcName = 0;

	// 取得$WorkingDir 的重複名
	if ($iType == 0) {
		$iNameLen = strlen($DfileName);
		$arrFolder = glob($DfileName."*", GLOB_ONLYDIR);
		$iFolderLen = count($arrFolder);
		
		// 過濾不符合條件的 folderName
		if ($iFolderLen > 0){
			for ($i=0; $i<$iFolderLen; $i++){
				$bUnset = 0;
				$tmpFolderName = $arrFolder[$i];
				if ($tmpFolderName == $DfileName) $bSrcName = 1;
				$strLen = strlen($tmpFolderName);

				$strLen = $strLen * 1;
				if ($strLen > $iNameLen) {
					$tmpFolderName1 = substr($tmpFolderName, 0, $iNameLen+1);
					$endChar = substr($tmpFolderName, $strLen-1, 1);
				
					if ($tmpFolderName1 !== $DfileName.'(') {
						$bUnset = 1;	
					} else {
						if ($endChar !== ')') {
							$bUnset = 1;
						}
					}
				} 
				if ($bUnset == 1) {
					unset($arrFolder[$i]);
				} 
			}
			$iFolderLen = ($bSrcName == 0)? 0: count($arrFolder);

			if ($iFolderLen > 0) {
				if ($iFolderLen > 1) {
					sort($arrFolder);
					$tmpLastName = $arrFolder[$iFolderLen-1];
					list($baseName, $sTmpSerialNo) = explode('(', $tmpLastName);
					$iSerialNo = substr($sTmpSerialNo, 0, -1);
					$nuSerialNo = $iSerialNo * 1 + 1;
					$nuName = $baseName."(".$nuSerialNo.")";
				} else {
					$nuName = $DfileName."(1)";
				}
			} else {
				$nuName = $DfileName;
			}
		
		} else {
			$nuName = $DfileName;
		}	
	} else {
		$iNameLen = strlen($baseName);
		$arrFiles = glob($baseName."*.".$sExt);
		$iFilesLen = count($arrFiles);
		
		// 過濾不合條件的檔案
		if ($iFilesLen > 0) {
			for ($j=0; $j<$iFilesLen; $j++){
				$bUnset = 0;
				$tmpFileName = substr($arrFiles[$j], 0, -4);
				if ($tmpFileName == $baseName) $bSrcName = 1;

				$strLen2 = strlen($tmpFileName);
				$strLen2 = $strLen2 * 1;

				if ($strLen2 > $iNameLen) {
					$tmpFileName1 = substr($tmpFileName, 0, $iNameLen+1);
					$endChar = substr($tmpFileName, $strLen-1, 1);
				
					if ($tmpFileName1 !== $baseName.'(') {	
						$bUnset = 1;	
					} else {
						if ($endChar !== ')') {
							$bUnset = 1;
						}
					}
				}

				if ($bUnset == 1) {
					unset($arrFiles[$j]);
				}				 
			}
			$iFilesLen = ($bSrcName==0)? 0:count($arrFiles);
			
			if ($iFilesLen > 0) {
				if ($iFilesLen > 1) {
					sort($arrFiles);
					// array由小至大排序, 有括號排前面, 沒括號排後面
					$tmpLastName = $arrFiles[$iFilesLen-2];				
					list($baseName1, $sTmpSerialNo) = explode('(', $tmpLastName);
					$iSerialNo = substr($sTmpSerialNo, 0, 1);
					$iSerialNo = $iSerialNo * 1;					
					$nuSerialNo = $iSerialNo + 1;
					$nuName = $baseName."(".$nuSerialNo.").".$sExt;				
				} else {
					$nuName = $baseName."(1).".$sExt;
				}

			} else {
				$nuName = $baseName.".".$sExt;
			}
						
		} else {
			$nuName = $baseName.".".$sExt;
		}						
	}

	chdir($oldPath);	
	return $nuName;
}

function chk_twpid($id) {
	// 台灣身份證檢查函數
    if( !$id )return false;
    $id = strtoupper(trim($id)); //將英文字母全部轉成大寫，消除前後空白
    //檢查第一個字母是否為英文字，第二個字元1 2 A~D 其餘為數字共十碼
    $ereg_pattern= "^[A-Z]{1}[12ABCD]{1}[[:digit:]]{8}$";
    if(!ereg($ereg_pattern, $id))return false;
    $wd_str="BAKJHGFEDCNMLVUTSRQPZWYX0000OI";   //關鍵在這行字串
    $d1=strpos($wd_str, $id[0])%10;
    $sum=0;
    if($id[1]>='A')$id[1]=chr($id[1])-65; //第2碼非數字轉換依[4]說明處理
    for($ii=1;$ii<9;$ii++)
        $sum+= (int)$id[$ii]*(9-$ii);
    $sum += $d1 + (int)$id[9];
    if($sum%10 != 0)return false;
    return true;
}

function getRanColorHex($startv, $darkflag = false){
/**
  * 函數名稱：string getRanColorHex($startv, $darkflag)
  * 功能：隨機產生一個顏色字串
  * @param $startv: start value, an integer 0-255, 0:darkest(black) to 255:white
  * @param $darkflag: true:from $startv to darker value; false:from $startv to lighter value。(true向前演色、false向後淺色)
  * @return a color string. 回傳：字串(ex.#123456, #ABCDEF)
  * ex: getRanColorHex(200,false) create an light color string which lightest color value is 200 產生一個淺色的字串
  * ex: getRanColorHex(70,true) create an dark color string 產生一個深色的字串，最淺的顏色是70
  */

   mt_srand((double)microtime()*1000000);
   $cv=0;
   for($ii=0;$ii<3;$ii++){
     if($darkflag) $v =mt_rand(0,$startv);
     else  $v =mt_rand($startv,255);
     $cv+= $v<< $ii*8;
   }
   $hex= str_pad(dechex($cv), 6, "0", STR_PAD_LEFT);
   return "#".$hex;	
} 
?>