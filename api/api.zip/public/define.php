<?php
/*******************************************************
2021/09/15 updated by james lin
1. 
********************************************************/
$prePath = ($iSubProg == 1)? "../": "";

define ('ROOT_DIR', '/var/www/html');
define ('SITE_URL','http://www.liwasite.com/');
define ('SITE_NAME','雲系統');
define ('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

if ( isset ( $_SERVER['HTTP_HOST'] ) ){
	define ('ROOT_URL','http://'.$_SERVER['HTTP_HOST'].'/');
}else{
	define ('ROOT_URL','http://127.0.0.1/');
}

define ('REPORT_URL','http://127.0.0.1/'.$siteID.'/archive/'.$siteID.'/報告/');
?>