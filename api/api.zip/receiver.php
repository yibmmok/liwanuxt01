<?php
// Handle remote upload
if (isset($_POST['fileName']) && $_POST['fileData'])
{
    // 判斷$fileName所屬folder 是否存在
    $fileName = $_POST['fileName'];
    $sTmpFolder = substr($fileName, 0, 6);
    $msg = '';
    $uploadDir = '../pics/'.$sTmpFolder;

    if (!file_exists($uploadDir)) {
        $oldPath = getcwd();
        chdir('../pics/');
        mkdir($sTmpFolder);
        chmod($sTmpFolder, 0777);
        chdir($oldPath);
    }
    // Save uploaded file
    file_put_contents(
        $uploadDir.'/'. $fileName,
        $_POST['fileData']
    );

    // Done
    $msg  = '/pics/'.$sTmpFolder.'/'.$fileName;
    echo $msg;
}
?>