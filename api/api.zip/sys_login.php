<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include_once("./util.php");
include_once("./class/Mysql.class.php");
require_once("./JWT.php");

	$json = file_get_contents('php://input');
	$data = json_decode($json);
	$arrjson = array();
	$token = '';

	$usermail = $data->usermail;
	$pswd = $data->password;
	$token = $data->jwttoken;
	$resetFlag = false;
	$siteIcon = '';
	$msg = '';

	// 先取得 jwt 的siteID, expTime, userID
	if (!empty($token)) {
		$arrPayload = Jwt::verifyToken($token);
		$expTime = $arrPayload['exp'] - 14400;
		$userID = $arrPayload['sub'];
		$siteID = $arrPayload['siteID'];
	} else {
		$resetFlag = true;
	}

	$db = new MySQLDB('liwa05', 'utf8mb4');
	$SQL = "select userID, username, originSiteID, iStatus, iconPath, password from W02_M where usermail='".$usermail."'";
	$result = $db->query($SQL);
	$liwaData = $result->fetch(PDO::FETCH_ASSOC);
	if (password_verify($pswd, $liwaData['password'])) {
		$siteID = $liwaData['originSiteID'];
		// 若有 originSiteID, 另取得 siteIcon, uGroupID, uGroupName, auth
		if (!empty($liwaData['originSiteID'])) {
			if ($liwaData['iStatus'] == -1) {
				$msg = '帳號尚未確認, 請至收件匣確認';
			} else {
				// 取得 siteIcon
				$SQL_siteIcon = "select logoPic, compName from 004_M where siteID='".$siteID."'";
				$result_siteIcon = $db->query($SQL_siteIcon);
				$row_siteIcon = $result_siteIcon->fetch(PDO::FETCH_ASSOC);
				$siteIcontmp = $row_siteIcon['logoPic'];
				$siteName = $row_siteIcon['compName'];
				$siteIcon = (!empty($siteIcontmp))? $siteIcontmp: $siteIcon;
				// 取得 uGroupID, uGroupName, auth
				$SQL_002M = "select uGroupID, uGroupName, iAuth from 002_M where siteID='".$siteID."'";
				$result_002M = $db->query($SQL_002M);
				$row002M = $result_002M->fetch(PDO::FETCH_ASSOC);
				$uGroupID = $row002M['uGroupID'];
				$uGroupName = $row002M['uGroupName'];
				$iAuth = $row002M['iAuth'];				
			}
		} else {
			$uGroupID = '';
			$uGroupName = '';
			$iAuth = 0;
			$siteIcon = '';
			if ($liwaData['iStatus'] !== '0') $msg = '帳號尚未確認, 請至收件匣確認';
		}

		// 取得圖檔機預設值
		$data1 = file_get_contents('./json/'.$siteID.'.json');
		$arrData = json_decode($data1, true);	
		$imgsvr = $arrData['imgsvr'];
		$apisvr = $arrData['apisvr'];

		// 若 jwt token為空, 重設 jwt token 並回傳jwt token
		if (empty($token)) {
			$resetFlag = true;
		} else {
			// 檢查 jwt token 的 exp 是否到期, 若到期則重發
			if ($expTime < time()) $resetFlag = true;
		}	
		if ($resetFlag == true) {
			// 重設JWT
			$exptime = (time()+604800)*1000;
			$time_set = time()*1000;
			$arrNewPayload = array('iss'=>'liwa0admin', 'iat'=>$time_set, 'exp'=>$exptime, 'nbf'=>$time_set, 'sub'=>$liwaData['userID'], 'username'=>$liwaData['username'], 'iconPath'=>$liwaData['iconPath'], 'auth'=>$iAuth, 'uGroupID'=>$uGroupID, 'uGroupName'=>$uGroupName, 'siteID'=>$siteID, 'siteIcon'=>$siteIcon, 'siteName'=>$siteName, 'imgsvr'=>$imgsvr, 'apisvr'=>$apisvr);
			$token = Jwt::getToken($arrNewPayload);
		}			
		array_push($arrjson, array('userID'=>$liwaData['userID'], 'username'=>$liwaData['username'], 'iconPath'=>$liwaData['iconPath'], 'token'=>$token, 'auth'=>$iAuth, 'uGroupID'=>$uGroupID, 'uGroupName'=>$uGroupName, 'siteID'=>$siteID, 'siteIcon'=>$siteIcon, 'siteName'=>$siteName, 'imgsvr'=>$imgsvr, 'apisvr'=>$apisvr, 'message'=>$msg));

	} else {
		$msg = '密碼與帳號不符!';
		array_push($arrjson, array('userID'=>'', 'iStatus'=>'', 'siteID'=>'', 'token'=>'', 'message'=>$msg));	
	} 
	echo json_encode(array('arrSQL'=>$arrjson));				

	$db->close();
	// print_r($data);
?>
