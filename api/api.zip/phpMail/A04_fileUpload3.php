<?php
include_once("util.php");
include_once("config_liwas.php");

	//header('Content-Type: application/json; charset=utf-8');

	$error = "";
	$msg = "";

	$userID = $_POST['userID'];
	$oldFile = $_POST['oldFile'];
	$fileName1 = $_FILES['fileinput']['name'];
	$iStrlen = strlen($fileName1);
	$ext = substr($fileName1, $iStrlen-3, 3);
	
	$FileName = urldecode("../Tmp/".$_FILES['fileinput']['name']);	
	$shortName = urldecode($fileName1);
	$newFile = getRanCode(12);
	$bFlag = false;
	while (!$bFlag) {
		// 檢查 $newFile 在TempPic內是否有相同檔名
		$dirs = glob("../TempPic/".$newFile.".png");
		$iCount = count($dirs);
		if ($iCount == 0) {
			$bFlag = true;
		} else {
			$newFile = getRanCode(12);
		}
	}
	
	if (move_uploaded_file($_FILES['fileinput']['tmp_name'], $FileName))
	{		
		// 先將檔案存到Tmp, 若寬高皆大於200, 則縮圖, 否則將檔案直接copy 到TempPic
		list($iWidth, $iHeight) = getimagesize($FileName);
		chmod($FileName, 0777);
		
		if (($iWidth < 201) && ($iHeight < 201)) {
			$iStrlen = strlen($shortName);
			$ext = substr($shortName, $iStrlen-3, 3);
			$dstFileName = "../TempPic/".$newFile.".".$ext;
			rename($FileName, $dstFileName);
		} else {
			$tempName = imgScale($FileName, 200, 200, $newFile, FALSE);
			chmod("../TempPic/".$tempName, 0777);
			$dstFileName = "TempPic/".$tempName;
			unlink($FileName);
		}
		
		// 將更新的圖檔路徑存到W02_M內
		$SQL = "update W02_M set picpath='".$dstFileName."' where userID='".$userID."'";
		$result = $connecDB->exec($SQL);
		if ($result ==0 ) {
			$err = $connecDB->errorCode();
			if (($err!=='00000') || ($err!=='01000')) {
				$msg .= "Error ".$err.":無法變更使用者圖檔;".$SQL.";";
			} 			
		} 
		
		// 更新 A10_D1
		$SQL_A10D1 = "update A10_D1 set userIcon='".$dstFileName."' where userID='".$userID."'";
		$result_A10D1 = $connecDB->exec($SQL_A10D1);
		if ($result_A10D1==0) {
			$errA10D1 = $connecDB->errCode();
			if (($errA10D1!='00000')||($errA10D1!='01000')) {
				$msg .= "Error ".$errA10D1.":聊天室頭像無法更新;".$SQL_A10D1.";";
			}
		}
		unlink("../".$oldFile);
		
		if (!$connecDB) mysql_close($connecDB);  // 若資料庫連結未斷, 下指令中斷
	} else {
		$dstFileName = "";
	}
	header('Content-Type: application/json');
	die(json_encode(array('error'=>$error, 'msg'=>$msg, 'oldFile'=>$oldFile, 'FileName'=>$FileName, 'key'=>$dstFileName, 'SQL'=>$SQL)));			
?>