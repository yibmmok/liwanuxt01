<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include_once("./util.php");
include_once("./class/Mysql.class.php");
include_once("./phpMail/PHPMailerAutoload.php");
include_once("./phpqrcode/qrlib.php");
date_default_timezone_set("Asia/Taipei");

	$json = file_get_contents('php://input');
	$data = json_decode($json);
	$action = $data->action;
	$siteID = $data->siteID;
	$userID = $data->userID;
	$makerName = $data->makerName;
	$mainID = $data->mainID;
	$username = $data->username;
	$nickname = $data->nickname;
	$gender = $data->gender;
	$uGroupID = $data->uGroupID;
	
	$iAuth = $data->iAuth;
	$isTop = $data->isTop;
	$birthday = (empty($data->birthday))? '': date("Y/m/d", strtotime($data->birthday));
	$addr = $data->addr;
	$zip = $data->zip;
	$phone = $data->phone;
	$mobile = $data->mobile;
	$usermail = $data->usermail;
	$roles = $data->roles;
	$iStatus = $data->iStatus;
	$iconPath = $data->iconPath;
	$memo = '';
	$iLenD1 = 0;

	$ownerID = $siteID."010001";
	$msg = '';
	$sKey = '';
	$connecDB = new MySQLDB('liwa05', 'utf8mb4');
	$SQL_003M = "select uGroupName from 003_M where uGroupID='".$uGroupID."'";
	$result_003M = $connecDB->query($SQL_003M);
	$uGroupName = $connecDB->queryUniqueValue($result_003M);

	// 取得預設值
	$data1 = file_get_contents('./json/'.$siteID.'.json');
	$arrData = json_decode($data1, true);
	$isPublic = $arrData['isPublic'];
	$isPublic = $isPublic * 1;
	$manPic = $arrData['man-pic'];
	$manIcon = $arrData['man-icon'];
	$womanPic = $arrData['woman-pic'];
	$womanIcon = $arrData['woman-icon'];
	$ServerDomain = $arrData['ServerDomain'];
	$imgsvr = $arrData['imgsvr'];
	$apisvr = $arrData['apisvr'];
	$A02MDate = date('Y/m/d H:i');
	$bExecFlag = true;
	$remoteURL = $imgsvr."/php/receiver.php";

	$SQL_haveOwner = "select clubName as owner from 010_M where siteID='".$siteID."' and mainID='".$ownerID."'";
	$result_haveOwner = $connecDB->query($SQL_haveOwner);
	$owner = $connecDB->queryUniqueValue($result_haveOwner);

	// 取得已加入的程式 progID
	$arrProgID = array();
	$SQL_getProgID = "select progID from 001_M where siteID='".$siteID."'";
	$result_getProgID = $connecDB->query($SQL_getProgID);
	$iCount1 = 0;
	while($rowProgID = $result_getProgID->fetch(PDO::FETCH_ASSOC)) {
		$arrProgID[$iCount1] = $rowProgID['progID'];
		$iCount1 ++;
	}

	if (($action == 'add') || ($action == 'edit')) {
		$picHead = substr($iconPath, 0, 5);

		if ($picHead == 'data:') {
			// 若 action == 'edit', 先找原檔案, 設unlinkfile
			$SQL_unlinkfile = "select iconPath from W02_M where userID='".$mainID."'";
			$result_unlinkfile = $connecDB->query($SQL_unlinkfile);
			$unlinkfile = $connecDB->queryUniqueValue($result_unlinkfile);
			// 取得新檔名
			$fileNo = rand(100000, 999999);
			$fileName = date("YmdHi").$fileNo.".png";
			$spath = date("Ym");
			list($type, $iconPathTmp) = explode(';', $iconPath);
			list(, $fileData) = explode(',', $iconPathTmp);
			$uploadRequest = array(
				'siteID' => $siteID,
				'action' => $action,
				'unlinkfile' => $unlinkfile,
				'spath'=> $spath,
				'fileName' => $fileName,
				'fileData' => $fileData
			);

			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, $remoteURL);
			curl_setopt($curl, CURLOPT_TIMEOUT, 200);
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $uploadRequest);
			$response = curl_exec($curl);
			if (curl_error($curl)) $msg .= curl_error($curl);
			curl_close($curl);
			
			if ($response == '/'.$siteID.'/'.$spath.'/'.$fileName) {
				// $nuIconPath = $response;
				$iconPath = $response;
				$picpath = $response;
			} else {
				$msg .= $response;
			}
		} 		
	}

	if ($action == 'add') {
		// 設定 picpath & iconPath
		if (($iconPath == '../static/man-icon.png') || ($iconPath == '../static/woman-icon.png'))  {
			$picpath = ($gender == '先生')? '/syspics/man-icon.png': '/syspics/woman-icon.png';
			$iconPath = ($gender == '先生')? '/syspics/man-icon.png': '/syspics/woman-icon.png';
		}	
		// 若 action == 'add', 先用usermail 檢查使用者是否已存在
		$SQL_chkW02M = "select userID, username from W02_M where usermail='".$usermail."'";
		$result_chkW02M = $connecDB->query($SQL_chkW02M);
		$rowChkW02M = $result_chkW02M->fetch(PDO::FETCH_ASSOC);	
		if ((empty($rowChkW02M['userID'])) ) {
			// 若 userID為空
			if ($rowChkW02M['username'] !== $username) {
				$nuID = '';
				while ($nuID == '') {
					$nuID = getRanCode(10);
					$SQL_nuID = "select userID from W02_M where userID='".$nuID."'";
					$result_nuID = $connecDB->query($SQL_nuID);
					$tmpID = $connecDB->queryUniqueValue($result_nuID);
					if (!empty($tmpID)) $nuID = '';
				}
				$mainID = $nuID;
				$password = getRanCode(8);
				$pswd_hash = password_hash($password, PASSWORD_DEFAULT);

				$sDate1 = date('Y/m/d');
				// 先新增 W02_M
				$SQL_addW02M = "insert into W02_M(userID, username, nickname, gender, birthday, phone, mobile, usermail, password, zip, addr, originSiteID, onboard, roles, picpath, iconPath, iStatus) values ('".$mainID."', '".$username."', '".$username."', '".$gender."', '".$birthday."', '".$phone."', '".$mobile."', '".$usermail."', '".$pswd_hash."', '".$zip."', '".$addr."', '".$siteID."', '".$A02MDate."', '".$roles."', '".$picpath."', '".$iconPath."', 0)";
				try {
					$result_addW02M = $connecDB->exec($SQL_addW02M);
				}	
				catch (Exception $e) {
					$err_addW02M = $connecDB->errorInfo();
					if (($err_addW02M[0] !== '00000') && ($err_addW02M[0]!=='01000')) {
						$msg .= "Error ".$err_addW02M[0].": 無法新增W02_M的資料.".$e->getMessage()."SQL=".$SQL_addW02M.";";
					}
				}				
			} 					
		} else {
			// 若 userID 已存在, 仍要檢查username是否相同, 才能設定mainID
			if ($rowChkW02M['username'] == $username) {
				$mainID = $rowChkW02M['userID'];
			} 	
			$bExecFlag = false;			
		}

		
		// 重設邀請碼
		$inviteCode = getInviteCode($siteID);

		$inviteLink = $apisvr.'/inviteLink.php?inviteCode='.$inviteCode.'&tutorID='.$userID;		
		$QRFileName = date("YmdHi").getRanCode(6).'.png';
		$pngCode = QRcode::png($inviteLink, './tmp/'.$QRFileName, QR_ECLEVEL_L,4);
		chmod("./tmp/".$QRFileName, 0777);
		$uploadRequest1 = array(
			'siteID' => 'qrcode',
			'spath' => date("Ym"),
			'fileName' => $QRFileName,
			'fileData' => base64_encode(file_get_contents('./tmp/'.$QRFileName))
		);

		$curl1 = curl_init();
		curl_setopt($curl1, CURLOPT_URL, $remoteURL);
		curl_setopt($curl1, CURLOPT_TIMEOUT, 30);
		curl_setopt($curl1, CURLOPT_POST, 1);
		curl_setopt($curl1, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl1, CURLOPT_POSTFIELDS, $uploadRequest1);
		$response1 = curl_exec($curl1);
		if (curl_error($curl1)) $msg .= curl_error($curl1);
		curl_close($curl1);
		unlink('./tmp/'.$QRFileName);
		$QRcodePic = $response1;
		// if ($response1 == '/qrcode/'.$spath.'/'.$QRFileName) {
		// 	unlink('./tmp/'.$QRFileName);
		// 	$QRcodePic = $response1;
		// } else {
		// 	$msg .= $response1;
		// 	$bExecFlag = false;
		// }		

		// 新增 002_M的資料, 
		$iStatusTmp = ($isPublic == 1) ? 0: -1; // 因雲系統為公有或私有, 設定 iStatus
		$SQL1 = "insert into 002_M (siteID, mainID, nickname, uGroupID, uGroupName, iAuth, isTop, iStatus, memo, isTutor, inviteLink, qrCodePath) values ('".$siteID."', '".$mainID."', '".$username."', '".$siteID."02', 'member', ".$iAuth.", 0, ".$iStatusTmp.", '".$memo."', 1, '".$inviteLink."', '".$QRcodePic."')";
		if ($bExecFlag) {
			try {
				$result = $connecDB->exec($SQL1);
				if ($isPublic == 1) {
					// 直接新增使用者相關資料
					if (in_array('A09', $arrProgID)) {
						// insert new record into table A09_D3
						$SQL_addA09D3 = "insert into A09_D3 (siteID, evTypeID, evType, backColor, fontColor, iLevel) values ('".$siteID."', '".$mainID."001', '".$username."', '#FFFFFF', '#000000', 1)";
						try {
							$result_addA09D3 = $connecDB->exec($SQL_addA09D3);
						}
						catch (Exception $e) {
							$err_A09D3 = $connecDB->errorInfo();
							if (($err_A09D3[0]!=='00000')&&($err_A09D3[0]!=='01000')) {
								$msg .= "Error ".$err_A09D3[0].": 無法新增個人事件類別;".$e->getMessage().";SQL=".$SQL_addA09D3;
							}				
						}								
					} // in_array(A09) 結尾
					// insert record into table 002_D1
					$accessTime = date('Y/m/d H:i:s'); 
					$SQL_have001M = "select progID from 003_D1 where siteID='".$siteID."' and uGroupID='".$siteID."02' order by progID";
					$result_have001M = $connecDB->query($SQL_have001M);
					while($row001M = $result_have001M->fetch(PDO::FETCH_ASSOC)){
						$sProgID = $row001M['progID'];
						$SQL_002D1 = "insert into 002_D1 (siteID, mainID, progID, accessTime) values ('".$siteID."', '".$mainID."', '".$sProgID."', '".$accessTime."')";
						try {
							$result_002D1 = $connecDB->exec($SQL_002D1);
						}
						catch (Exception $e) {
							$err_002D1 = $connecDB->errorInfo();
							if (($err_002D1[0]!=='00000') && ($err_002D1[0]!=='01000')) {
								$msg .= "Error ".$err_002D1[0].": 無法新增002_D1的".$sProgID."資料;".$e->getMessage().";SQL=".$SQL_002D1.";";
							}		
						}		
					}// 新增 002_D1結尾	
					// insert new record into table 002_D2 (預設 A02, A06, A09)
					$SQL_have001M2 = "select progID, LMName, imgPath, slink, lang from 001_M where siteID='".$siteID."' and progID in ('A02', 'A06', 'A09')"; 
					$result_have001M2 = $connecDB->query($SQL_have001M2);
					$iOrder = 1;
					while($row001M2 = $result_have001M2->fetch(PDO::FETCH_ASSOC)){
						$SQL_002D2 = "insert into 002_D2 (siteID, mainID, progID, LMName, picpath, slink, iOrder, lang) values ('".$siteID."', '".$mainID."', '".$row001M2['progID']."', '".$row001M2['LMName']."', '".$row001M2['imgPath']."', '".$row001M2['slink']."', ".$iOrder.", 'tw')";
						try {
							$result_002D2 = $connecDB->exec($SQL_002D2);
						}
						catch (Exception $e) {
							$err_002D2 = $connecDB->errorInfo();
							if (($err_002D2[0]!=='00000') && ($err_002D2[0]!=='01000')) {
								$echoMsg = getSysMsg('sys_InitProcess23', '');
								$msg .= "Error ".$err_002D2[0].": ".$echoMsg.$e->getMessage().";SQL=".$SQL_002D2.";";
							}		
						}
						$iOrder = $iOrder + 1;		
					} // 新增 002_D2 結尾
					// insert new record into table 002_D3
					$SQL_add002D3 = "insert into 002_D3 (siteID, mainID, evTypeID) values ('".$siteID."', '".$mainID."', '".$siteID."A09001'), ('".$siteID."', '".$mainID."', '".$mainID."001'), ('".$siteID."', '".$mainID."', '".$siteID."010001')";
					try {
						$result_add002D3 = $connecDB->exec($SQL_add002D3);
					}
					catch (Exception $e) {
						$err_add002D3 = $connecDB->errorInfo();
						if (($err_add002D3[0]!=='00000') && ($err_add002D3[0]!=='01000')) {
							$msg .= "Error ".$err_add002D3[0].": 無法新增002_D3的資料;".$e->getMessage().";SQL=".$SQL_add002D3.";";
						}		
					} // 新增 002_D3 結尾
					// insert new record into table 002_D5
					$SQL_add002D5 = "insert into 002_D5 (siteID, mainID, fmGroupID) values ('".$siteID."', '".$mainID."', '".$siteID."008001'), ('".$siteID."', '".$mainID."', '".$siteID."010001')";
					try {
						$result_add002D5 = $connecDB->exec($SQL_add002D5);
					}
					catch (Exception $e) {
						$err_add002D5 = $connecDB->errorInfo();
						if (($err_add002D5[0]!=='00000') && ($err_add002D5[0]!=='01000')) {
							$msg .= "Error ".$err_add002D5[0].": 無法新增002_D5的資料;".$e->getMessage().";SQL=".$SQL_add002D5.";";
						}		
					} // 新增 002_D5結尾	
					// set sDate & anID in table 005_M
					$sDate = date('Y/m/d H:i');
					$offDate = getDateShift($sDate, '+7');
					$SQL_005M = "select max(mainID) as maxID from 005_M where siteID='".$siteID."'";
					$result_005M = $connecDB->query($SQL_005M);
					$row_005M = $result_005M->fetch(PDO::FETCH_ASSOC);
					$max_ID005 = $row_005M['maxID'];
					$ID005 = increaseID($max_ID005, 0, 9);
					
					$SQL_add005M = "insert into 005_M (siteID, mainID, pDate, offDate, itemTypeID, itemType, items, shortItems) values ('".$siteID."', '".$ID005."', '".$sDate."', '".$offDate." 18:00', '".$siteID."01', '系統公告', '<p>歡迎新成員(".$username.")加入!</p>', '新成員(".$username.")加入公告')";
					try {
						$result_add005M = $connecDB->exec($SQL_add005M);
					}
					catch (Exception $e) {
						$err_005M = $connecDB->errorInfo();
						if (($err_005M[0]!=='00000')&&($err_005M[0]!=='01000')) {
							$msg .= "Error ".$err_005M[0]."無法新增系統公告:".$e->getMessage().";SQL=".$SQL_add005M;
						}				
					} // 新增 005_M結尾
					// insert new record in table A02_M
					$slink = "/A08/".$mainID;
					$slink2 = "/005/".$ID005;
					$SQL_A02M = "insert into A02_M (siteID, docID, progID, docType, docName, ownerID, owner, iProcess, slink, crt_UserID, crt_UserNM, crt_Time) values ('".$siteID."', '".$mainID."', 'A08', '通訊錄', '".$username."', '".$siteID."010001', (select clubName from 010_M where siteID='".$siteID."' and mainID='".$siteID."010001'), 0, '".$slink."', '".$userID."', '".$makerName."', '".$A02MDate."'), ('".$siteID."', '".$ID005."', '005', '公告', '新成員(".$username.")加入公告', '".$siteID."010001', (select clubName from 010_M where siteID='".$siteID."' and mainID='".$siteID."010001'), 0, '".$slink2."', '".$userID."', '".$makerName."', '".$A02MDate."')";
					try {
						$result_A02M = $connecDB->exec($SQL_A02M);
					}
					catch (Exception $e) {
						$err_A02M = $connecDB->errorInfo();
						if (($err_A02M[0]!=='00000') && ($err_A02M[0]!=='01000')) {
							$echoMsg = "";
							$msg .= "Error ".$err_A02M[0].": 無法新增A02_M的記錄;".$e->getMessage().";SQL=".$SQL_A02M.";";
						}			
					} // 新增 A02_M 結尾
					
					// 發 email 告知密碼, 先取得 mailer parameters
					$host = $arrData['host'];
					$port = $arrData['port'];
					$usernameMail = $arrData['maileraddr'];
					$passwd = $arrData['mailerpswd'];
					$FromName = $arrData['FromName'];
					$ssl = $arrData['sslData'];	

					// 取得004_M 的 compName 欄位
					$SQL_004M = "select compName from 004_M where siteID='".$siteID."'";
					$result_004M = $connecDB->query($SQL_004M);
					// $row004M = $result_004M->fetch(PDO::FETCH_ASSOC);
					$compName = $connecDB->queryUniqueValue($result_004M);

					// Send activate mail
					$mail= new PHPMailer(); // new PHPMailer
					$mail->IsSMTP(); // Send by SMTP
					$mail->SMTPAuth = true; // SMTP needs verification
					if ($ssl) {
						$mail->SMTPSecure = $ssl; // Set up SSL 
					}
					
					$mail->Host = $host; // set up SMTP hosting
					$mail->Port = $port; // Set up SMTP port, default port 290
					$mail->CharSet = "utf-8"; // set up char coding
					 
					$mail->Username = $usernameMail; // set up mailer account
					$mail->Password = $passwd; // set up mailer password
					 
					$mail->From = $usernameMail; // set up mailer box
					$mail->FromName = $FromName; // set up mailer name  
					
					$mail->Subject = $compName.'雲系統新使用者通知'; // set up mail title
					
					$sContent = '<p>'.$username.'您好'.'</p><br/><br/><p>您已經成功成為'.$compName.'雲系統的使用者, 您的登入帳號為'.$usermail.'</p><p>您的密碼為 '.$password.'</p><p>系統首頁的網址為'.$ServerDomain.'</p><p>請依下列步驟進入系統:</p><p>1. 點擊系統首頁右上方的「登入」按鈕。</p><p>2. 在登入頁輸入您的登入帳號及密碼, 首次登入後, 系統將記住您的帳號密碼。若不願意系統記憶密碼, 請完全登出系統即可。</p><p>3. 按「登入」按鈕。</p><p>4. 您可以開始使用您的雲系統了。</p><br/><br/><p>此為系統自動發送信件, 請勿直接回覆本信。</p>';

					$mail->Body = $sContent; // set mail content
					$mail->IsHTML(true); // set HTML mail   
					$mail->AddAddress($usermail, $username); // set mail address and name of receipt  

					if(!$mail->Send()) {   
						$msg.= "Mailer Error: ". $mail->ErrorInfo;   
					} else {
						// 先取得 mail ID
						$SQLID = "select max(mainID) as maxID from A13_M where siteID='".$siteID."'";
						$resultID = $connecDB->query($SQLID);
						// $rowID = $resultID->fetch(PDO::FETCH_ASSOC);
						$A13ID = $connecDB->queryUniqueValue($resultID);
						if ($A13ID) {
							$nuA13ID = increaseID($A13ID, 0, 9);
						} else {
							$nuA13ID = $siteID."A1300001";
						}
						//  取得 siteID.010001名稱
						$SQL_have010M = "select mainID, clubName from 010_M where siteID='".$siteID."' and mainID='".$siteID."010001'";
						$result_have010M = $connecDB->query($SQL_have010M);
						$rowHave010M = $result_have010M->fetch(PDO::FETCH_ASSOC);
						$ownerID = $rowHave010M['mainID'];
						$owner = $rowHave010M['clubName'];
						// 	將發信資訊加入A13_M 內	
						$SQL_addA13M = "insert into A13_M(siteID, mainID, clubID, clubName, title, sendTime, content) values ('".$siteID."', '".$nuA13ID."', '".$ownerID."', '".$owner."', '".$compName."雲系統新使用者通知', '".$sDate."', '".$sContent."')";
						try {
							$result_addA13M = $connecDB->exec($SQL_addA13M);
						}
						catch (Exception $e) {
							$err_addA13M = $connecDB->errorInfo();
							if (($err_addA13M[0] !== '00000') && ($err_addA13M[0]!=='01000')) {
								$msg .= "Error ".$err_addA13M[0].": 無法新增A13_M的資料.".$e->getMessage()."SQL=".$SQL_addA13M.";";						
							}
						}
						// 	將發信資訊加入A13_D1 內	
						$SQL_addA13D1 = "insert into A13_D1(siteID, mainID, userID, userName, usermail) values ('".$siteID."', '".$nuA13ID."', '".$mainID."', '".$username."', '".$usermail."')";
						try {
							$result_addA13D1 = $connecDB->exec($SQL_addA13D1);
						}
						catch (Exception $e) {
							$err_addA13D1 = $connecDB->errorInfo();
							if (($err_addA13D1[0] !== '00000') && ($err_addA13D1[0]!=='01000')) {
								$msg .= "Error ".$err_addA13D1[0].": 無法新增A13_D1的資料.".$e->getMessage()."SQL=".$SQL_addA13D1.";";						
							}
						}
						// Append data in table A02_M
						$slink = "/A13/".$nuA13ID;
						$SQL_addA02MA13 = "insert into A02_M(siteID, docID, progID, docType, docName, ownerID, owner, iProcess, slink, crt_UserID, crt_UserNM, crt_Time) values ('".$siteID."', '".$nuA13ID."', 'A13', '郵件雲', '".$compName."雲系統新使用者通知', '".$siteID."010001', (select clubName from 010_M where siteID='".$siteID."' and mainID='".$siteID."010001'), 0, '".$slink."', '".$userID."', '".$makerName."', '".$A02MDate."')";
						try {
							$result_add02MA13 = $connecDB->exec($SQL_addA02MA13);
						}
						catch(Exception $e){
							$errAdd02MA13 = $connecDB->errorInfo();
							if (($errAdd02MA13[0]!=='00000') && ($errAdd02MA13[0]!=='010000')) {
								$msg .= "Error ".$errAdd02MA13[0].":無法新增A02_M的資料;".$e->getMessage().";SQL=".$SQL_addA02MA13.";";
							}
						}						
					} // 發信成功結尾
					// 處理user所加入的團體

				} // isPublic == 1結尾
			} // 新增002 detail 結尾
			catch (Exception $e) {
				$err1 = $connecDB->errorInfo();
				if (($err1[0] !=='00000') && ($err1[0] !== '00001')) {
					$msg .= "Error ".$err1[0].": 無法新增使用者(".$username.");".$e->getMessage()."SQL=".$SQL1.";";
				}
			}			
		} // 執行 002_M結尾
		$sKey = $mainID;
	} // action == add 結尾
	if ($action == 'edit') {		
		$SQL_haveW02M = "select gender, username, usermail from W02_M where userID='".$mainID."'";
		$result_haveW02M = $connecDB->query($SQL_haveW02M);
		$rowW02M = $result_haveW02M->fetch(PDO::FETCH_ASSOC);
		$bGender = ($rowW02M['gender']!==$gender)? true: false;
		$bUsername = ($rowW02M['username']!==$username)? true: false;
		$bUsermail = ($rowW02M['username']!==$usermail)? true: false;
		$picpath = $iconPath;

		$SQL_edit002MA = ($bUsername)?"update 002_M set nickname='".$nickname."', uGroupID='".$uGroupID."', uGroupName='".$uGroupName."', iAuth=".$iAuth.", isTop=".$isTop.", memo='".$memo."' where mainID = '".$mainID."' and siteID='".$siteID."'":"update 002_M set uGroupID='".$uGroupID."', uGroupName='".$uGroupName."', iAuth=".$iAuth.", isTop=".$isTop.", memo='".$memo."' where mainID = '".$mainID."' and siteID='".$siteID."'";
		try {
			$result_edit002MA = $connecDB->exec($SQL_edit002MA);
		}
		catch (Exception $e) {
			$err_edit002MA = $connecDB->errorInfo();
			if (($err_edit002MA[0] !== '00000') && ($err_edit002MA[0]!=='01000')) {
				$msg .= "Error ".$err_edit002MA[0].": 無法變更002_M的資料.".$e->getMessage()."SQL=".$SQL_edit002MA.";";						
			}
		} // 修改002_M 結尾
		
		$SQL1 = "update W02_M set username='".$username."', nickname='".$nickname."', gender='".$gender."', usermail='".$usermail."', birthday='".$birthday."', addr='".$addr."', zip='".$zip."', phone='".$phone."', mobile='".$mobile."', picpath='".$picpath."', iconPath='".$iconPath."' where userID='".$mainID."'";
		if ($bExecFlag)	{
			try {
				$result1 = $connecDB->exec($SQL1);
				if ($iStatus == 0) {
					// 先判斷 $isTop == 1, 若是, 尋找目前超級管理者的userID(不需檢查uGroupName, 在js已檢查)
					if ($isTop == 1) {
						$SQL_isTop = "select mainID from 002_M where siteID='".$siteID."' and isTop=1";
						$result_isTop = $connecDB->query($SQL_isTop);
						// $rowTop = $result_isTop->fetch(PDO::FETCH_ASSOC);
						$oldUserID = $connecDB->queryUniqueValue($result_isTop);
						if ($oldUserID !== $mainID) {
							// 將所有isTop設為0
							$SQL_edit002M = "update 002_M set isTop=0 where siteID='".$siteID."'";
							try {
								$result_edit002M = false;
								$result_edit002M = $connecDB->exec($SQL_edit002M);
							}
							catch (Exception $e) {
								$err_edit002M = $connecDB->errorInfo();
								if (($err_edit002M[0] !== '00000') && ($err_edit002M[0]!=='01000')) {
									$msg .= "Error ".$err_edit002M[0].": 無法設定002_M的isTop欄位.".$e->getMessage()."SQL=".$SQL_edit002M.";";
								}
							}
						} // 若是超級管理員已變更的處理結束
						// 若加入 detailD1時再處理
						if ($iLenD1 > 0) {
							// $SQL_del010D1 = "delete from 010_D1 where siteID='".$siteID."' and userID='".$mainID."'";
							// try {
							// 	$result_del010D1 = $connecDB->exec($SQL_del010D1);
							// }	
							// catch(Exception $e){
							// 	$err_del010D1 = $connecDB->errorInfo();
							// 	if (($err_del010D1[0] !== '00000') && ($err_del010D1[0]!=='01000')) {
							// 		$msg .= "Error ".$err_del010D1[0].": 無法010_D1的資料.".$e->getMessage()."SQL=".$SQL_del010D1.";";	
							// 	}
							// }  // 刪除 010_D1 的處理結尾
							// $SQL_delA10D2 = "delete from A10_D2 where siteID='".$siteID."' and userID='".$mainID."'";
							// try {
							// 	$result_delA10D2 = $connecDB->exec($SQL_delA10D2);
							// }	
							// catch(Exception $e){
							// 	$err_delA10D2 = $connecDB->errorInfo();
							// 	if (($err_delA10D2[0] !== '00000') && ($err_delA10D2[0]!=='01000')) {
							// 		$msg .= "Error ".$err_delA10D2[0].": 無法A10_D2的資料.".$e->getMessage()."SQL=".$SQL_delA10D2.";";
							// 	}
							// } // 刪除 A10_D2的處理結尾
							// **  新增 010_D1 & A10_D2, 預先取得 iconPath  **
							// $DiconPath = $iconPath;
							// for ($iCount1=0; $iCount1<$iLenD1; $iCount1++){
							// 	$DclubID = $detailD1[$iCount1]['clubID'];
							// 	$Dkeyman = $detailD1[$iCount1]['keyman'];
							// 	$SQL_add010D1 = "insert into 010_D1 (siteID, mainID, userID, userName, keyman) values ('".$siteID."', '".$DclubID."', '".$mainID."', '".$username."', ".$Dkeyman.")";
							// 	try
							// 	{
							// 		$result_add010D1 = $connecDB->exec($SQL_add010D1);
							// 	}
							// 	catch (Exception $e) {
							// 		$errAdd010D1 = $connecDB->errorInfo();
							// 		if (($errAdd010D1[0]!=='00000')&&($errAdd010D1[0]!=='01000')) {
							// 			$msg .= "Error ".$errAdd010D1[0].":"."無法新增010_D1的資料;".$e->getMessage().";SQL=".$SQL_add010D1.";";
							// 		}
							// 	}
							// 	if (in_array('A10', $arrProgID)) {
							// 		$SQL_addA10D2 = "insert into A10_D2 (siteID, mainID, userID, username, userIcon) values ('".$siteID."', '".$DclubID."', '".$mainID."', '".$username."', '".$DiconPath."')";
							// 		try {
							// 			$result_addA10D2 = $connecDB->exec($SQL_addA10D2);
							// 		}
							// 		catch (Exception $e) {
							// 			$errAddA10D2 = $connecDB->errorInfo();
							// 			if (($errAddA10D2[0]!=='00000')&&($errAddA10D2[0]!=='01000')) {
							// 				$msg .= "Error ".$errAddA10D2[0].":"."無法新增A10_D2的資料;".$e->getMessage().";SQL=".$SQL_addA10D2.";";
							// 			}
							// 		}
							// 	}
							// }	// ** 新增 010_D1 & A10_D2 的處理結尾 **
							// ** 變更 username 的處理 **
						}	
						if ($bUsername) {
							// 變更關聯 table的 username值, 變更 002_D7 Table
							$SQL_edit002D7 = "update 002_D7 set userName = '".$username."' where siteID='".$siteID."' and userID='".$mainID."'";
							try {
								$result_edit002D7 = $connecDB->exec($SQL_edit002D7);
							}
							catch (Exception $e) {
								$err_edit002D7 = $connecDB->errorInfo();
								if (($err_edit002D7[0]!=='00000')&&($err_edit002D7[0]!=='01000')) {
									$msg .= "Error ".$err_edit002D7[0].": 無法變更 002_D7的userName欄位;".$e->getMessage().";SQL=".$SQL_edit002D7;
								}
							}  // 變更 002_D7 的處理結束
							if ($iLenD1 > 0) {
								// $SQL_edit010D1B = "update 010_D1 set userName='".$username."' where siteID='".$siteID."' and userID='".$mainID."'";
								// try {
								// 	$result_edit010D1B = $connecDB->exec($SQL_edit010MB);
								// }
								// catch (Exception $e) {
								// 	$err_edit010D1B = $connecDB->errorInfo();
								// 	if (($err_edit010D1B[0]!=='00000')&&($err_edit010D1B[0]!=='01000')) {
								// 		$msg .= "Error ".$err_edit010D1B[0].": 無法變更 010_D1的userName欄位;".$e->getMessage().";SQL=".$SQL_edit010D1B;
								// 	}
								// } //變更 010_D1 的處理結束
								// if (in_array('A10', $arrProgID)) {
								// 	$SQL_editA10D2B = "update A10_D2 set username='".$username."' where siteID='".$siteID."' and userID='".$mainID."'";
								// 	try {
								// 		$result_editA10D2B = $connecDB->exec($SQL_editA10D2B);
								// 	}
								// 	catch (Exception $e) {
								// 		$err_editA10D2B = $connecDB->errorInfo();
								// 		if (($err_editA10D2B[0]!=='00000')&&($err_editA10D2B[0]!=='01000')) {
								// 			$msg .= "Error ".$err_editA10D2B[0].": 無法變更 A10_D2的username欄位;".$e->getMessage().";SQL=".$SQL_editA10D2B;
								// 		}
								// 	}
								// } // 變更 A10_D2 結尾
							} // iLenD1 > 0 處理結尾
							if (in_array('A09', $arrProgID)) {
								$SQL_editA09D3B = "update A09_D3 set evType='".$username."' where siteID='".$siteID."' and evTypeID='".$mainID."001'";
								try {
									$result_editA09D3B = $connecDB->exec($SQL_editA09D3B);
								}
								catch (Exception $e) {
									$err_editA09D3B = $connecDB->errorInfo();
									if (($err_editA09D3B[0]!=='00000')&&($err_editA09D3B[0]!=='01000')) {
										$msg .= "Error ".$err_editA09D3B[0].": 無法變更 A09_D3的evType欄位;".$e->getMessage().";SQL=".$SQL_editA09D3B;
									}
								}							
							}	// 變更 A09_D3 行事曆 結尾
							if (in_array('008', $arrProgID)) {
								$SQL_edit008M1B = "update 008_M set createUser='".$username."' where siteID='".$siteID."' and createUserID='".$mainID."'";
								try {
									$result_edit008M1B = $connecDB->exec($SQL_edit008M1B);
								}
								catch (Exception $e) {
									$err_edit008M1B = $connecDB->errorInfo();
									if (($err_edit008M1B[0]!=='00000')&&($err_edit008M1B[0]!=='01000')) {
										$msg .= "Error ".$err_edit008M1B[0].": 無法變更 008_M的createUser欄位;".$e->getMessage().";SQL=".$SQL_edit008M1B;
									}
								}
								$SQL_edit008M2B = "update 008_M set lastUser='".$username."' where siteID='".$siteID."' and lastUserID='".$mainID."'";
								try {
									$result_edit008M2B = $connecDB->exec($SQL_edit008M2B);
								}
								catch (Exception $e) {
									$err_edit008M2B = $connecDB->errorInfo();
									if (($err_edit008M2B[0]!=='00000')&&($err_edit008M2B[0]!=='01000')) {
										$msg .= "Error ".$err_edit008M2B[0].": 無法變更 008_M的lastUser欄位;".$e->getMessage().";SQL=".$SQL_edit008M2B;
									}
								}
							}  // 變更 008_M 處理結尾	
							if (in_array('A13', $arrProgID)) {
								$SQL_editA13D1B = "update A13_D1 set userName='".$username."' where siteID='".$siteID."' and userID='".$mainID."'";
								try {
									$result_editA13D1B = $connecDB->exec($SQL_editA13D1B);
								}
								catch (Exception $e) {
									$err_editA13D1B = $connecDB->errorInfo();
									if (($err_editA13D1B[0]!=='00000')&&($err_editA13D1B[0]!=='01000')) {
										$msg .= "Error ".$err_editA13D1B[0].": 無法變更 A13_D1的userName欄位;".$e->getMessage().";SQL=".$SQL_editA13D1B;
									}
								}													
							}  // 變更 A13_D1 的處理結尾
						}  // bUsername的處理結尾
						// 變更 usermail 的處理
						if ($bUsermail) {
							if (in_array('A13', $arrProgID)) {
								$SQL_editA13D1C = "update A13_D1 set usermail='".$usermail."' where siteID='".$siteID."' and userID='".$mainID."'";
								try {
									$result_editA13D1C = $connecDB->exec($SQL_editA13D1C);
								}
								catch (Exception $e) {
									$err_editA13D1C = $connecDB->errorInfo();
									if (($err_editA13D1C[0]!=='00000')&&($err_editA13D1C[0]!=='01000')) {
										$msg .= "Error ".$err_editA13D1C[0].": 無法變更 A13_D1的userName欄位;".$e->getMessage().";SQL=".$SQL_editA13D1C;
									}
								}													
							}
						} // bUsermail 的處理結尾
					}  // isTop == 1 的處理結尾
					// 正式會員處理結尾
				} else { 
					// 準成員的處理, 新增 010_D1 & A10_D2, 預先取得 iconPath
					// $DiconPath = $iconPath;
					// for ($iCount1=0; $iCount1<$iLenD1; $iCount1++){
					// 	$DclubID = $detailD1[$iCount1]['clubID'];
					// 	$SQL_add010D1 = "insert into 010_D1 (siteID, mainID, userID, userName, keyman) values ('".$siteID."', '".$DclubID."', '".$mainID."', '".$username."', 0)";
					// 	try
					// 	{
					// 		$result_add010D1 = $connecDB->exec($SQL_add010D1);
					// 	}
					// 	catch (Exception $e) {
					// 		$errAdd010D1 = $connecDB->errorInfo();
					// 		if (($errAdd010D1[0]!=='00000')&&($errAdd010D1[0]!=='01000')) {
					// 			$msg .= "Error ".$errAdd010D1[0].":"."無法新增010_D1的資料;".$e->getMessage().";SQL=".$SQL_add010D1.";";
					// 		}
					// 	}  // 新增 010_D1 處理結尾
					// 	// 新增 A10_D2的處理
					// 	if (in_array('A10', $arrProgID)) {
					// 		$SQL_addA10D2 = "insert into A10_D2 (siteID, mainID, userID, username, userIcon) values ('".$siteID."', '".$DclubID."', '".$mainID."', '".$username."', '".$DiconPath."')";
					// 		try
					// 		{
					// 			$result_addA10D2 = $connecDB->exec($SQL_addA10D2);
					// 		}
					// 		catch (Exception $e) {
					// 			$errAddA10D2 = $connecDB->errorInfo();
					// 			if (($errAddA10D2[0]!=='00000')&&($errAddA10D2[0]!=='01000')) {
					// 				$msg .= "Error ".$errAddA10D2[0].":"."無法新增A10_D2的資料;".$e->getMessage().";SQL=".$SQL_addA10D2.";";
					// 			}
					// 		}	// 新增 A10_D2 的處理結尾
					// 	}  // 若A10在可執行程式列表內結尾					

					// }  // 新增 010_D1 & A10_D2 的處理結尾
				}  // 準成員的處理結束
				$sRename = (($bUsername))?"set docName='".$username."', ":"";
				$SQL_editA02MB="update A02_M set ".$sRename."mdf_UserID='".$userID."', mdf_UserNM='".$makerName."', mdf_Time='".$A02MDate."' where siteID='".$siteID."' and docID= '".$mainID."' and progID='A08'";
				try {
					$result_editA02MB = $connecDB->exec($SQL_editA02MB);
				}
				catch (Exception $e) {
					$err_editA02MB = $connecDB->errorInfo();
					if (($err_editA02MB[0]!=='00000')&&($err_editA02MB[0]!=='01000')) {
						$msg .= "Error ".$err_editA02MB[0].": 無法變更 A02_M的資料;".$e->getMessage().";SQL=".$SQL_editA02MB;
					}
				}	// 變更 A02_M 的處理結尾			
			} // 修改 002 detail 結尾
			catch (Exception $e) {
				$err1 = $connecDB->errorInfo();
				if (($err1[0] !=='00000') && ($err1[0] !== '00001')) {
					$msg .= "Error ".$err1[0].": 無法變更使用者(".$username.")資料;".$e->getMessage()."SQL=".$SQL1.";";
				}
			}			
		} // bExecFlag 結尾
		$sKey = $mainID;
	} // action == edit 結尾
	if ($action == 'delete') {
		$detailStr = $data->details;
		$details = explode(',', $detailStr);
		$iLength = count($details);
		$SQL_topUser = "select mainID, nickname from 002_M where siteID='".$siteID."' and isTop=1";
		$result_topUser = $connecDB->query($SQL_topUser);
		$row_topUser = $result_topUser->fetch(PDO::FETCH_ASSOC);
		$topUserID = $row_topUser['mainID'];
		$topUserNM = $row_topUser['nickname'];	
		for ($iCount = 0; $iCount < $iLength; $iCount++) {
			$DmainID = $details[$iCount];
			// 必須 DmainID <> $topUserID 才可以刪除
			if ($DmainID !== $topUserID) {
				// 將待刪 User所屬文件所有的管理員欄位值都換成最高管理員
				$SQL_edit002D7 = "update 002_D7 set mainID='".$topUserID."', leader='".$topUserNM."' where siteID='".$siteID."' and mainID='".$DmainID."'";
				try {
					$result_edit002D7 = $connecDB->exec($SQL_edit002D7);
				}
				catch(Exception $e){
					$err_edit002D7 = $connecDB->errorInfo();
					if (($err_edit002D7[0]!=='00000')&&($err_edit002D7[0]!=='01000')) {
						$msg .= "Error ".$err_edit002D7[0].":無法變更002_D7的mainID, leader欄位;".$e->getMessage().";SQL=".$SQL_edit002D7;
					}			
				}
				// 在A02_M 設定 active_FLG, del_UserID, del_userNM, del_Time
				$SQL_editA02M = "update A02_M set active_FLG=0, del_UserID='".$userID."', del_UserNM='".$makerName."', del_Time='".$A02MDate."' where siteID='".$siteID."' and docID='".$DmainID."' and progID='A08'";
				try {
					$result_editA02M = $connecDB->exec($SQL_editA02M);
				}
				catch(Exception $e){
					$err_editA02M = $connecDB->errorInfo();
					if (($err_editA02M[0]!=='00000')&&($err_editA02M[0]!=='01000')) {
						$msg .= "Error ".$err_editA02M[0].":無法刪除使用者(編號:(".$DmainID.");".$e->getMessage().";SQL=".$SQL_editA02M;
					}			
				}	
				// 刪除 A09_D3
				$SQL_delA09D3 = "delete from A09_D3 where siteID='".$siteID."' and ownerID='".$DmainID."'";
				try {
					$result_delA09D3 = false;
					$result_delA09D3 = $connecDB->exec($SQL_delA09D3);
				}
				catch(Exception $e){
					$err_delA09D3 = $connecDB->errorInfo();
					if (($err_delA09D3[0]!=='00000')&&($err_delA09D3[0]!=='01000')) {
						$msg .= "Error ".$err_delA09D3[0].":無法刪除使用者個人事件;".$e->getMessage().";SQL=".$SQL_delA09D3;
					}			
				}				
			}
		} // 刪除待刪的使用者處理結尾			
	}

	if ($msg) {
		$sLog_Msg = $userID.", ".$msg;
		writUserLog($sLog_Msg, $siteID);
	}

	success($msg, $sKey);
?>