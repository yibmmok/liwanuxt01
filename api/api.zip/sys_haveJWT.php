<?php
header("Access-Control-Allow-Origin: *");
include_once("./util.php");
include_once("./class/Mysql.class.php");
require_once("./JWT.php");
date_default_timezone_set("Asia/Taipei");

if ($_GET)
{
	$token = $_GET['token'];
	$arrPayload = Jwt::verifyToken($token);
	$exptime = (time()+604800)*1000;
	$time_set = time()*1000;	
	$arrNewPayload = array('iss'=>'liwa0admin', 'iat'=>$time_set, 'exp'=>$exptime, 'nbf'=>$time_set, 'sub'=>$arrPayload['sub'], 'username'=>$arrPayload['username'], 'iconPath'=>$arrPayload['iconPath'], 'auth'=>$arrPayload['auth'], 'uGroupID'=>$arrPayload['uGroupID'], 'uGroupName'=>$arrPayload['uGroupName'], 'siteID'=>$arrPayload['siteID'], 'siteIcon'=>$arrPayload['siteIcon'], 'siteName'=>$arrPayload['siteName']);
	$token = Jwt::getToken($arrNewPayload);	
			
	// success($token, '');
	echo json_encode(array('token'=>$token));
}
?>