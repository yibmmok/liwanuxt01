<?php
header("Access-Control-Allow-Origin: *");
include_once("./util.php");
include_once("./class/Mysql.class.php");
require_once("./JWT.php");

if ($_GET)
{
	$arrjson = array();

	$db = new MySQLDB('liwa05', 'utf8');
	// 解 jwt token, 取得 userID
	$token = $_GET['jwttoken'];
	$arrPayload = Jwt::verifyToken($token);
	$expTime = $arrPayload['exp'] - 14400;
	$userID = $arrPayload['sub'];
	$siteID = empty($arrPayload['siteID'])?'liwa05':$arrPayload['siteID'];

	if ($expTime < time()) {
		$arrNewPayload = array('iss'=>'liwa0admin', 'iat'=>time(), 'exp'=>time()+604800, 'nbf'=>time(), 'sub'=>$liwaData['userID'], 'siteID'=>$liwaData['originSiteID']);
		$token = Jwt::getToken($arrNewPayload);
	}	
	if (!empty($userID)) {
		// 取得 userID, originSiteID, userID, userName, auth, uGroupID, uGroupName, iconPath
		$SQL = "select A.userID, A.username, A.originSiteID, A.picpath as iconPath, B.uGroupID, B.uGroupName, B.iAuth as auth, B.iStatus from W02_M A, 002_M B where A.userID=B.mainID and A.userID='".$userID."' and B.siteID='".$siteID."'";
		$result = $db->query($SQL);
		while ($liwaData = $result->fetch(PDO::FETCH_ASSOC)) {
			array_push($arrjson, array('userID'=>$userID, 'siteID'=>$liwaData['originSiteID'], 'username'=>$liwaData['username'], 'uGroupID'=>$liwaData['uGroupID'], 'uGroupName'=>$liwaData['uGroupName'], 'auth'=>$liwaData['auth'], 'iStatus'=>$liwaData['iStatus'], 'liwakey'=>$token, 'iconPath'=>$liwaData['iconPath']));
		}
	} else {
		array_push($arrjson, array('userID'=>'', 'siteID'=>'', 'username'=>'', 'uGroupID'=>'', 'uGroupName'=>'', 'auth'=>'0', 'iStatus'=>'1', 'liwakey'=>$token, 'iconPath'=>''));		
	}

	echo json_encode($arrjson);

	$db->close();
}
?>