<?php
header("Access-Control-Allow-Origin: *");
include_once("./util.php");
include_once("./class/Mysql.class.php");
date_default_timezone_set("Asia/Taipei");

if ($_GET) {
	$siteID = $_GET['siteID'];
	$arrjson = array();
	$msg = '';
	$db = new MySQLDB('liwa05', 'utf8mb4');
	$SQL = "select uGroupID, uGroupName from 003_M where siteID='".$siteID."'";
	$result = $db->query($SQL);
	$arrjson = $db->fetchDataArray($result);

	echo json_encode(array('arrSQL'=>$arrjson));

	$db->close();
}
?>