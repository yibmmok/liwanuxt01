<?php
header("Access-Control-Allow-Origin: *");
include_once("./util.php");
include_once("./class/Mysql.class.php");
date_default_timezone_set("Asia/Taipei");

if ($_GET)
{
	$userID = $_GET['userID'];
	$mainID = isset($_GET['mainID'])?$_GET['mainID']:"";	
	$filterUsername = $_GET['filterName'];
	$filterEmail = $_GET['filterEmail'];
	$filterRoles = $_GET['filterRole'];
	$filterOnboard1 = $_GET['filterOnboard1'];
	$filterOnboard2 = $_GET['filterOnboard2'];
	$orderCol = (empty($_GET['orderCol']))?"A.username":$_GET['orderCol'];
	$sortDir = (empty($_GET['sortDir']))?"asc":$_GET['sortDir'];
	$progID = '002';
	$msg = '';

	if ((!$orderCol) && (!$sortDir)) {
			$orderStr = 'A.username asc';
	} else {
		$orderStr = "A.".$orderCol." ".$sortDir;
	}

	$filter = "";
	$arrjson = array();
	$msg = '';

	if ((empty($filterUsername)) && (empty($filterEmail)) && (empty($filterRoles)) && (empty($filterOnboard1)) && (empty($filterOnboard2))) { 			
		$filter = "1";
	} else {
		if (!empty($filterUsername)) {
			$filter .= "(A.username like '%".$filterUsername."%')";
		}

		if (!empty($filterEmail)) {
			if (empty($filter)) {
				$filter .= "(A.usermail like '%".$filterEmail."%')";
			} else {
				$filter .= " and (A.usermail like '%".$filterEmail."%')";
			}
		}

		if (!empty($filterRoles)) {
			if (empty($filter)) {
				if ($filterRoles == '準成員') {
					$filter .= "(A.iStatus = -1)";
				} else {
					$filter .= "(A.iStatus = 0)";
				}
			} else {
				if ($filterRoles == '準成員') {
					$filter .= " and (A.iStatus = -1)";
				} else {
					$filter .= " and (A.iStatus = 0)";
				}					
			}
		}

		if (!empty($filterOnboard1)) {
			if (empty($filter)) {
				$filter .= "(A.onboard >= '".$filterOnboard1."')";
			} else {
				$filter .= " and (A.onBoard >= '".$filterOnboard1."')";
			}
		}

		if (!empty($filterOnboard2)) {
			if (empty($filter)) {
				$filter .= "(A.onboard <= '".$filterOnboard2."')";
			} else {
				$filter .= " and (A.onBoard <= '".$filterOnboard2."')";
			}
		}		
	}				

	
	// $filter = (empty($mainID))? "": " where mainID='".$mainID."'";
	$db = new MySQLDB('liwa05', 'utf8mb4');
	$page = (isset($_GET['page']))?$_GET['page']:0;
	$limit = (isset($_GET['pageSize']) && $_GET['pageSize']>0)?$_GET['pageSize']:10;
	if (empty($mainID)) {
		
		$SQL_page = "select COUNT(A.userID) as count from W02_M A where A.userID <> 'liwa0admin' and ".$filter;
		$result_page = $db->query($SQL_page);		
		$count = $db->queryUniqueValue($result_page);		
		$total_pages = ($count > 0)?ceil($count/$limit):1; // get all pages
		if ($page > $total_pages) $page=$total_pages;		
		// get start record
		$start = $limit*$page - $limit; 
		if ($start < 0) $start = 0;	
		$SQL = "select A.userID as mainID, A.username, A.usermail, A.onboard, A.picpath, A.roles, A.loginTime, 0 as isChecked, C.mainID as mainIDC from W02_M A left outer join (select mainID from A11_M where siteID='".$siteID."' and userID='".$userID."' and progID='".$progID."') C on A.userID=C.mainID left outer join (select docID from A02_M where siteID='".$siteID."' and progID='".$progID."' and active_FLG=1) D on A.userID=D.docID where A.userID <> 'liwa0admin' and ".$filter." order by ".$orderCol." ".$sortDir." limit ".$start.", ".$limit;		
	} else {
		$SQL = "select A.username, A.nickname, A.gender, A.usermail, A.birthday, A.zip, A.addr, A.phone, A.mobile, A.originSiteID, A.picpath, A.iconPath, A.roles, A.iSites, A.iStatus from W02_M A where userID = '".$mainID."'";
	}
	// $SQL = "select userID as mainID, username, usermail, onboard, roles, iconPath, loginTime from W02_M".$filter;
	$result = $db->query($SQL);
	$liwaData = $db->fetchDataArray($result);

	if (empty($mainID)) {
		echo json_encode(array('totalPage'=>$total_pages, 'arrSQL'=>$liwaData, 'message'=>$msg));
	} else {
		echo json_encode(array('arrSQL'=>$liwaData));
	}
	
	$db->close();
}
?>