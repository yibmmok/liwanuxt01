<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
include_once("./util.php");
include_once("./class/Mysql.class.php");
include_once("./phpMail/PHPMailerAutoload.php");

	$json = file_get_contents('php://input');
	$data = json_decode($json);
	$userName = $data->username;
	$usermail = $data->email;
	$password = $data->password;
	$pswd_hash = (empty($password))?"":password_hash($password, PASSWORD_DEFAULT);

	// 設定註冊時間
	$sDate = date('Y/m/d');
	$userID = getRanCode(10);	
	$userFlag = false;
	$db = new MySQLDB('liwa05', 'utf8mb4');
	// check if the userID exists in table W02_M
	while (!$userFlag) {
		$SQL = "select userID from W02_M where userID='".$userID."'";
		$result = $db->query($SQL);
		$row = $result->fetch(PDO::FETCH_ASSOC);
		$userID_chk = $row['userID'];		
		if ($userID_chk == $userID) {
			$userID = getRanCode(10);
		} else {
			$userFlag = true;
		}
	}

	$actvCode = getUUID(rand(0,9));

	$msg = '';
	$sKey = '';

	if ($pswd_hash) {
		$SQL1 = "insert into W02_M (userID, username, nickname, usermail, password, onboard, roles, iStatus, actvCode) values ('".$userID."', '".$userName."', '".$userName."', '".$usermail."', '".$pswd_hash."', '".$sDate."', '準會員', -1, '".$actvCode."')";
		try {
			$result1 = false;
			$result1 = $db->exec($SQL1);

			$SQL_addW02D5 = "insert into W02_D5 (userID, siteID) values('".$userID."', '".$siteID."')";
			try {
				$result_addW02D5 = false;
				$result_addW02D5 = $db->exec($SQL_addW02D5);
			}
			catch (Exception $e) {
				$err_addW02D5 = $db->errorInfo();
				if (($err_addW02D5[0]!=='00000') && ($err_addW02D5[0]!=='01000')) {
					$msg .= "Error ".$err_addW02D5[0].": 無法新增W02_D5的資料;".$e->getMessage().";SQL=".$SQL_addW02D5.";";
				}		
			}			
		}
		catch (Exception $e) {
			$err = $db->errorInfo();
			if (($err[0]!=='00000') && ($err[0]!=='01000')) {
				$msg .= "Error ".$err[0].": 無法新增W02_M的資料;".$e->getMessage().";SQL=".$SQL1.";";
			}		
		}
		// get mailer parameters
		$Domaindata = file_get_contents('./json/Params.json');
		$arrDomain = json_decode($Domaindata, true);	
		$ServerDomain = $arrDomain['ServerDomain'];

		// get mailer parameters
		if (empty($siteID)) $siteID='liwa05';
		$maildata = file_get_contents('./json/'.$siteID.'.json');
		$arrMail = json_decode($maildata, true);
		$host = $arrMail['host'];
		$port = $arrMail['port'];
		$maileraddr = $arrMail['maileraddr'];
		$mailerpswd = $arrMail['mailerpswd'];
		$FromName = $arrMail['FromName'];
		$ssl = $arrMail['sslData'];	
		
		// Send activate mail
		$mail= new PHPMailer(); // new PHPMailer
		$mail->IsSMTP(); // Send by SMTP
		$mail->SMTPAuth = true; // SMTP needs verification
		if ($ssl) {
			$mail->SMTPSecure = $ssl; // Set up SSL 
		}
		$mail->Host = $host; // set up SMTP hosting
		$mail->Port = $port; // Set up SMTP port, default port 290
		$mail->CharSet = "utf-8"; // set up char coding
		 
		$mail->Username = $maileraddr; // set up mailer account
		$mail->Password = $mailerpswd; // set up mailer password
		 
		$mail->From = $maileraddr; // set up mailer box
		$mail->FromName = $FromName; // set up mailer name  
		
		$mail->Subject = 'Liwasite 雲系統新使用者驗證通知及使用說明'; // set up mail title
		$inviteParam = ($inviteCode)?"&inviteCode=".$inviteCode:"";
		$slink = $ServerDomain.DS."ActvCode.html?userID=".$userID."&actvCode=".$actvCode.$inviteParam;
		
		$sContent = '<p>'.$userName.'您好,</p><br/><br/><p>您已成功註冊 Liwasite雲系統, 請點擊以下的連結驗證您的Email:</p><p><a href="'.$slink.'">'.$slink.'</a></p><br/><p>請依下列步驟登入本系統:</p><p>1. 點擊系統首頁右上方的「登入」按鈕</p><p>2. 在登入頁輸入您的email及密碼, 若所使用的裝置非公用電腦, 請勾選「記住我」</p><p>3.按「登入」</p><p>4. 您可以開始使用您的雲系統了。</p><br/><br/><p>此為系統自動發送信件, 請勿直接回復本信。</p>';

		$mail->Body = $sContent; // set mail content
		$mail->IsHTML(true); // set HTML mail   
		$mail->AddAddress($usermail, $userName); // set mail address and name of receipt  

		if(!$mail->Send()) {   
			$msg.= "Mailer Error: ". $mail->ErrorInfo;   
			fail($msg);
		} else {   
			//$msg .= "請開啟信箱閱讀新手使用須知, 再依步驟登入。";
			success($msg, $userID);
		}	
			
	} else {
		$msg = "密碼加密失敗, 請重試;";
		fail($msg);		
	}	

	// $msg .= $username;
	// $sKey .= $userID;

	// success($msg, $sKey);
	$db->close();
?>