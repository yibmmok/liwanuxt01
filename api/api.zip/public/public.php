<?php

/****************************************
2021/09/16 updated by james lin
1. 

*****************************************/
include_once ("define.php");
include_once ("Mysql.class.php");
include_once("liwalogger.php");
// require_once('pclzip.lib.php'); 
include_once("phpMail/PHPMailerAutoload.php");

require_once 'PHPExcel/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Ods;

$n = "\n";

ini_set('display_errors', false);

function SqlFilter($str){
	$str = str_replace("'","’",$str);
	$str = str_replace("\"","＂",$str);
	return $str;
}

if (!empty($_POST)){
	$CountVar = count($_POST);
	foreach ($_POST as $key => $value){
		$$key = $value;
	}
}else if (!empty($_GET)){
	$CountVar = count($_GET);
	foreach ($_GET as $key => $value){
		$$key = $value;
	}
}

function UserVerify(){
	if ((empty($_COOKIE['MUserID'])) || (empty($_COOKIE['MUserPWD']))){
		return FALSE;
	}else{
		return TRUE;
	}
}

function getBeforeDay($days,$db){
	$sql = "select to_char(sysdate-".$days.",'yyyy/mm/dd') from dual";
	$result = $db->query($sql);
	$BeforeDay = $db->queryUniqueValue($result);
	return $BeforeDay;
}

function getAfterDay ($date,$days){
	if (strlen($date) == 10){
		list($year,$month,$day) = split("[./-]",$date);
	}else if (strlen($date) == 8){
		$year = substr($date,0,4);
		$month = substr($date,4,2);
		$day = substr($date,6,2);
	}else {
		return;
	}
	$tomorrow  = date("Y/m/d",mktime(0, 0, 0, $month  , $day+$days, $year));
	return $tomorrow;
}

function getDistanceDays($DAY_ONE,$DAY_TWO){
    $A_DAYS = $DAY_ONE;
    $B_DAYS = $DAY_TWO;
    
    $temp_dob = explode("/",$A_DAYS);
	$temp_dob = mktime(0,0,0,$temp_dob[1],$temp_dob[2],$temp_dob[0]); 
	$temp_date = explode("/",$B_DAYS);
	$temp_date = mktime(0,0,0,$temp_date[1],$temp_date[2],$temp_date[0]); 
    
    $DISTANCE_DAYS = round(($temp_date - $temp_dob)/3600/24);    //相差天數
    
    return $DISTANCE_DAYS;
}

// download file dir exist or not 
function DownLoadPathExists (){
	/*************************  待改  *************************/
	if(!is_dir('download/'.date("Ymd"))) { 
		mkdir('download/'.date("Ymd"), 0777, true);
		chmod('download/'.date("Ymd"), 0777);
	}
	$filePath = 'download/'.date("Ymd").'/';
	return $filePath;
}

// upload file dir exist or not 
function UploadPathExists (){
	if(!is_dir('upload/'.date("Ymd"))) { 
		mkdir('upload/'.date("Ymd"), 0777, true);
		chmod('upload/'.date("Ymd"), 0777);
	}
	$filePath = 'upload/'.date("Ymd").'/';
	return $filePath;
}

// upload file dir exist or not 
function UploadPICPathExists (){
	if(!is_dir('PICUpload/'.date("Ymd"))) { 
		mkdir('PICUpload/'.date("Ymd"), 0777, true);
		chmod('PICUpload/'.date("Ymd"), 0777);
	}
	$filePath = 'PICUpload/'.date("Ymd").'/';
	return $filePath;
}

// // purchase order file dir exist or not 
// function POFilePath (){
// 	if(!is_dir('POFile/'.date("Ym"))) { 
// 		mkdir('POFile/'.date("Ym"), 0777, true);
// 		chmod('POFile/'.date("Ym"), 0777);
// 	}
// 	$filePath = 'POFile/'.date("Ym").'/';
// 	return $filePath;
// }

function WriteLog ($file_path,$message){
	$file = fopen($file_path,"a+");
	fputs($file,$message);
	fclose($file);
}

$PROD_SALE_AREA_ARRAY = array(
	'A'=>'沒有限制',
	'B'=>'限台灣本島加離島',
	'C'=>'限台灣本島'
);

$SUP_MODE_ARRAY = array(
	'A'=>'正常供貨',
	'B'=>'有貨通知'
);


$UNIT_ID_ARRAY = array(
	'A'=>'本',
	'B'=>'套',
	'C'=>'片',
	'D'=>'盒',
	'E'=>'包',
	'F'=>'箱',
    'G'=>'支',
    'H'=>'張',
    'J'=>'組',
    'K'=>'個',
    'L'=>'件',
    'M'=>'雙'
);

$SALE_PM_ARRAY = array(
	'A'=>'應稅',
	'B'=>'零稅',
	'C'=>'免稅'
);

$ORDER_STATUS_ARRAY = array(
	'A'=>'待確認',
	'B'=>'待抓單',
	'C'=>'處理中',
	'D'=>'已結案'
);

$OP_FLG_ARRAY = array(
	'C'=>'待揀貨',
	'D'=>'揀貨中',
	'E'=>'待分貨',
	'F'=>'分貨中',
	'H'=>'已出貨',
    'Z'=>'審核中',
	'R'=>'訂單取消'
);

$SO_STATUS_ARRAY = array(
	'A'=>'待處理',
	'B'=>'備貨中',
	'C'=>'待揀貨',
	'D'=>'揀貨中',
	'E'=>'待分貨',
	'F'=>'分貨中',
	'H'=>'已出貨',
    'Y'=>'配而不出',
    'Z'=>'不配不出',
	'R'=>'訂單取消'
);

$OI_FLG_ARRAY = array(
	'A'=>'待確認',
	'B'=>'處理中',
	'C'=>'備貨中',
	'D'=>'出貨準備中',
	'E'=>'已出貨',
	'R'=>'訂單取消'
);

$STK_FLG_ARRAY = array(
	'A'=>'進倉',
	'B'=>'寄倉',
	'C'=>'轉單',
	'D'=>'長備',
    'E'=>'下載'
);

/** =====  付款方式 ===========**/
$PM_METHOD_ARRAY = array(
    'A'=>'超商貨到付款',
    'B'=>'ATM',
    'C'=>'信用卡線上刷卡',
    'D'=>'信用卡傳真',
    'E'=>'支票',
    'F'=>'宅配貨到付款',
    'G'=>'手機付款',
    'H'=>'帳戶全額付款',
    'L'=>'LINE PAY'
);

$TAX_TYPE_ARRAY = array(
	'A'=>'應稅',
	'B'=>'零稅',
	'C'=>'免稅'
);

/** ===== 配送方式 ===== **/
$DELIVER_METHOD_ARRAY = array(
    'A'=>'超商',
    'B'=>'宅配',
    'C'=>'郵寄',
    'D'=>'下載',
    'E'=>'海運',
    'F'=>'航空',
    'G'=>'團購',
    'H'=>'員購',
    'N'=>'3小時'
);

$SND_STATUS_ARRAY = array(
	'A'=>'未到貨',
	'B'=>'驗收中',
	'C'=>'銷售中',
    'D'=>'待出貨',
    'E'=>'已出貨',
    'F'=>'分貨中',
    'G'=>'已出貨',
    'R'=>'停售下架'
);

$RET_DATA = array(
    'T00'=>'正常驗退',
    'T01'=>'閉店、整修、無路線路順',
    'T02'=>'無進貨資料',
    'T03'=>'條碼異常（錯誤、重覆）',
    'T05'=>'發生異常提早退貨',
    'T06'=>'30 日未驗取消',
    'S06'=>'小物流破損',
    'S07'=>'門市反應包裝不良',
    'N04'=>'通路取消出貨',
    'N05'=>'門市遺失',
    'D01'=>'大物流遺失',
    'D02'=>'未送貨到小物流',
    'D04'=>'大物流包裝不良',
    'D08'=>'大物流分貨錯誤'
);

// 退貨設定
$RET_ARRAY = ARRAY('T1'=>'ML','D1'=>'MM','S1'=>'MN','N1'=>'MP');

$PR_ARRAY = array(
	'A'=>'人員逐筆鍵入',
	'B'=>'',
	'C'=>'',
    'D'=>'店內碼批次匯入',
    'E'=>'物流條碼批次匯入',
    'K'=>'訂單轉入',
    'L'=>'理貨不足轉入',
    'M'=>'長備不足轉入',
    'N'=>'安存不足轉入',
    'P'=>'長備品首購匯入',
    'Q'=>'新品首購匯入'
);

$MY_ACCOUNT_SUBJECT_ARRAY = array(
	'01'=>'購買商品(-)',
	'02'=>'退貨退款(+)',
	'03'=>'',
    '04'=>'行銷分紅所得(+)',
    '05'=>'匯出現金(-)',
    '06'=>'匯出現金手續費(-)',
    '07'=>'取消訂單退款(+)',
    '08'=>'商品退回郵資(+)',
    '09'=>'買家退書溢滙扣回(-)',
    '99'=>'其他(+)'
);

$LANGUAGE_ARRAY = array(
	'01'=>'中文繁體',
	'02'=>'中文簡體',
	'03'=>'日文',
	'04'=>'韓文',
	'05'=>'泰文',
	'06'=>'英文',
	'07'=>'法文',
	'08'=>'德文',
	'09'=>'西班牙文',
	'10'=>'拉丁語',
	'11'=>'阿拉伯文',
	'12'=>'俄文',
	'13'=>'義大利文',
	'14'=>'荷蘭文',
	'15'=>'瑞典文',
	'16'=>'葡萄牙文',
	'17'=>'印尼語',
	'18'=>'比利時文',
	'19'=>'波蘭文',
	'20'=>'緬甸文'
);

$SO_CN_CDT_ARRAY = array(
	'AA'=>'全面開放',
	'HA'=>'僅開放全宅配取貨',
	'HH'=>'僅開放大榮取貨',
	'HS'=>'僅開放海外取貨',
	'MA'=>'僅開放全超商取貨',
	'MF'=>'僅開放全家取貨',
	'MK'=>'僅開放OK取貨',
	'ML'=>'僅開放萊爾富取貨',
	'ZZ'=>'全不開放'
);

$PO_CAT_ARRAY = array(
	'A'=>'常態',
	'B'=>'新品',
	'C'=>'客訂',
	'D'=>'補貨',
	'E'=>'特展',
	'F'=>'驗收補單'
);

$UNOINPAY_ARRAY = array(
    'A' => '聯合信用卡中心',
    'B' => '藍新科技',
    'L' => 'LINE Pay', 
    'Y' => '銀聯卡',
    'N' => ''
);

function Week($DATE){
	$unix_time = strtotime($DATE);
	$x = date('w', $unix_time);
	switch ($x) {
		case 1:
			$week = "一";
			break;
		case 2:
			$week = "二";
			break;
		case 3:
			$week = "三";
			break;
		case 4:
			$week = "四";
			break;
		case 5:
			$week = "五";
			break;
		case 6:
			$week = "六";
			break;
		case 0:
			$week = "日";
			break;
	}
	return $week;
}

$LANGUAGE_DATA = array(
	array ('LANGUAGE_ID'=>'01','LANGUAGE_NAME'=>'中文繁體'),
	array ('LANGUAGE_ID'=>'02','LANGUAGE_NAME'=>'中文簡體'),
	array ('LANGUAGE_ID'=>'03','LANGUAGE_NAME'=>'日文'),
	array ('LANGUAGE_ID'=>'04','LANGUAGE_NAME'=>'韓文'),
	array ('LANGUAGE_ID'=>'05','LANGUAGE_NAME'=>'泰文'),
	array ('LANGUAGE_ID'=>'06','LANGUAGE_NAME'=>'英文'),
	array ('LANGUAGE_ID'=>'07','LANGUAGE_NAME'=>'法文'),
	array ('LANGUAGE_ID'=>'08','LANGUAGE_NAME'=>'德文'),
	array ('LANGUAGE_ID'=>'09','LANGUAGE_NAME'=>'西班牙文'),
	array ('LANGUAGE_ID'=>'10','LANGUAGE_NAME'=>'拉丁語'),
	array ('LANGUAGE_ID'=>'11','LANGUAGE_NAME'=>'阿拉伯文'),
	array ('LANGUAGE_ID'=>'12','LANGUAGE_NAME'=>'俄文'),
    array ('LANGUAGE_ID'=>'13','LANGUAGE_NAME'=>'意大利文'),
    array ('LANGUAGE_ID'=>'14','LANGUAGE_NAME'=>'荷蘭文'),
    array ('LANGUAGE_ID'=>'15','LANGUAGE_NAME'=>'瑞典文'),
    array ('LANGUAGE_ID'=>'16','LANGUAGE_NAME'=>'葡萄牙文'),
    array ('LANGUAGE_ID'=>'17','LANGUAGE_NAME'=>'印尼語'),
    array ('LANGUAGE_ID'=>'18','LANGUAGE_NAME'=>'比利時文'),
    array ('LANGUAGE_ID'=>'19','LANGUAGE_NAME'=>'波蘭文'),
    array ('LANGUAGE_ID'=>'20','LANGUAGE_NAME'=>'緬甸文')
);

$CONTRAST_DATA = array(
	array ('CONTRAST_ID'=>'A0','CONTRAST_NAME'=>'無語文對照'),
	array ('CONTRAST_ID'=>'A1','CONTRAST_NAME'=>'中(繁)英對照'),
	array ('CONTRAST_ID'=>'A2','CONTRAST_NAME'=>'中(繁)日對照'),
	array ('CONTRAST_ID'=>'A3','CONTRAST_NAME'=>'中(繁)法對照')
);

$UNIT_DATA = array(
	array ('UNIT_ID'=>'A','UNIT_NAME'=>'本'),
	array ('UNIT_ID'=>'B','UNIT_NAME'=>'套'),
	array ('UNIT_ID'=>'C','UNIT_NAME'=>'片'),
	array ('UNIT_ID'=>'D','UNIT_NAME'=>'盒'),
	array ('UNIT_ID'=>'E','UNIT_NAME'=>'包'),
	array ('UNIT_ID'=>'F','UNIT_NAME'=>'箱'),
    array ('UNIT_ID'=>'G','UNIT_NAME'=>'支'),
    array ('UNIT_ID'=>'H','UNIT_NAME'=>'張'),
    array ('UNIT_ID'=>'J','UNIT_NAME'=>'組'),
    array ('UNIT_ID'=>'K','UNIT_NAME'=>'個'),
    array ('UNIT_ID'=>'L','UNIT_NAME'=>'件'),
    array ('UNIT_ID'=>'M','UNIT_NAME'=>'雙')
);

$PRINTING_DATA = array(
	array ('PRINTING_ID'=>'X','PRINTING_NAME'=>'未知'),
	array ('PRINTING_ID'=>'A','PRINTING_NAME'=>'單色印刷'),
	array ('PRINTING_ID'=>'B','PRINTING_NAME'=>'雙色印刷'),
	array ('PRINTING_ID'=>'C','PRINTING_NAME'=>'全彩印刷'),
	array ('PRINTING_ID'=>'D','PRINTING_NAME'=>'部分全彩')
);


$EDIT_TYPE_DATA = array(
	array ('EDIT_TYPE_ID'=>'X','EDIT_TYPE_NAME'=>'未知'),
	array ('EDIT_TYPE_ID'=>'A','EDIT_TYPE_NAME'=>'豎排'),
	array ('EDIT_TYPE_ID'=>'B','EDIT_TYPE_NAME'=>'橫排')
);

$OPEN_PR_CAT_DATA = array(
	array ('OPEN_PR_CAT_ID'=>'A','OPEN_PR_CAT_NAME'=>'全面開放'),
	array ('OPEN_PR_CAT_ID'=>'B','OPEN_PR_CAT_NAME'=>'僅開放新品'),
	array ('OPEN_PR_CAT_ID'=>'C','OPEN_PR_CAT_NAME'=>'僅開放客訂'),
	array ('OPEN_PR_CAT_ID'=>'D','OPEN_PR_CAT_NAME'=>'僅開放特展'),
	array ('OPEN_PR_CAT_ID'=>'E','OPEN_PR_CAT_NAME'=>'僅開放補貨'),
	array ('OPEN_PR_CAT_ID'=>'Z','OPEN_PR_CAT_NAME'=>'全不開放')
);

$SCREEN_RATIO_DATA = array(
	array ('SCREEN_RATIO_ID'=>'A','SCREEN_RATIO_NAME'=>''),
	array ('SCREEN_RATIO_ID'=>'B','SCREEN_RATIO_NAME'=>'16：9'),
	array ('SCREEN_RATIO_ID'=>'C','SCREEN_RATIO_NAME'=>'LETTERBOX')
);

$SO_CN_CDT_DATA = array(
	array ('SO_CN_CDT_ID'=>'AA','SO_CN_CDT_NAME'=>'全面開放'),
	array ('SO_CN_CDT_ID'=>'HA','SO_CN_CDT_NAME'=>'僅開放全宅配取貨'),
	array ('SO_CN_CDT_ID'=>'HH','SO_CN_CDT_NAME'=>'僅開放大榮取貨'),
	array ('SO_CN_CDT_ID'=>'HS','SO_CN_CDT_NAME'=>'僅開放海外取貨'),
	array ('SO_CN_CDT_ID'=>'MA','SO_CN_CDT_NAME'=>'僅開放全超商取貨'),
	array ('SO_CN_CDT_ID'=>'MF','SO_CN_CDT_NAME'=>'僅開放全家取貨'),
	array ('SO_CN_CDT_ID'=>'MK','SO_CN_CDT_NAME'=>'僅開放OK取貨'),
	array ('SO_CN_CDT_ID'=>'ML','SO_CN_CDT_NAME'=>'僅開放萊爾富取貨'),
	array ('SO_CN_CDT_ID'=>'ZZ','SO_CN_CDT_NAME'=>'全不開放')
);

$OPEN_PR_CAT_DATA = array(
	array ('OPEN_PR_CAT_ID'=>'A','OPEN_PR_CAT_NAME'=>'全面開放'),
	array ('OPEN_PR_CAT_ID'=>'B','OPEN_PR_CAT_NAME'=>'僅開放新品'),
	array ('OPEN_PR_CAT_ID'=>'C','OPEN_PR_CAT_NAME'=>'僅開放客訂'),
	array ('OPEN_PR_CAT_ID'=>'D','OPEN_PR_CAT_NAME'=>'僅開放特展'),
	array ('OPEN_PR_CAT_ID'=>'E','OPEN_PR_CAT_NAME'=>'僅開放補貨'),
	array ('OPEN_PR_CAT_ID'=>'Z','OPEN_PR_CAT_NAME'=>'全不開放')
);

function TransISBNLong($ISBN){
	$string = SUBSTR($ISBN,0,9);
	$x = "978".$string;
	$y = 1;
	$a = 1;
	$sum = 0;
	$new_isbn = '';
	for ($i=0; $i < 12; $i++ ){
		
		if ($y % 2 == 0){
			$a = 3;
		}else{
			$a = 1;
		}
		$c = substr($x,$i,1) * $a;	
		$sum = $sum + $c;
		
		$y ++;
	}
	$d = $sum % 10;
	if ($d == 0){
		$e = '0';
	}else{
		$e = 10 - $d;
	}
	$new_isbn = $x.$e;
	
	return $new_isbn;
}

function TransISBNShort($ISBN){
	$string = substr($ISBN,3,9);
	$a = 10;
	$sum = 0;
	for ($i=0; $i < 9; $i++ ){
		$c = substr($string,$i,1) * $a;	
		$sum = $sum + $c;
		$a--;
	}
	$d = $sum % 11;
	if ($d == 0){
		$new_isbn = $string.'0';
	}else{
		$e = 11 - $d;
		if (($e == 0) || ($e == 1)){
			$new_isbn = $string.'X';
		}else if ($e == 10) {
			$new_isbn = $string.'0';
		}else{
			$new_isbn = $string.$e;
		}
	}
	
	return $new_isbn;
}

function SendMail ($Subject,$MailContent,$MailTo,$AttachmentFile,$MailFrom='')
{
	/***********************  待改  **************************/
	$mail= new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->Host = "";
    $mail->Port = 25;
    $mail->CharSet = "utf-8";
    $mail->Encoding = "base64";
    
    $mail->Username = "";
    $mail->Password = "";
          
    $MailFrom = (!empty($MailFrom)) ? $MailFrom : "service@liwasite.com";
    $mail->From = $MailFrom;
    
    //$mail->From = "taazeintra@taaze.tw";
    $mail->FromName = "雲系統管理員";
          
    $mail->Subject = $Subject; //設定郵件標題        
    $mail->Body = $MailContent; //設定郵件內容        
    $mail->IsHTML(true); //設定郵件內容為HTML
    
    $CountMailTo = count($MailTo);
    for ($ii = 0; $ii < $CountMailTo; $ii++){
        $mail->AddAddress("$MailTo[$ii]"); //設定收件者郵件及名稱
    }    
            
    $CountAttachmentFile = count($AttachmentFile);
    for ($ii = 0; $ii < $CountAttachmentFile; $ii++){
        $mail->AddAttachment("$AttachmentFile[$ii]"); //設定附件檔案
    }
    
    if(!$mail->Send()) {        
        return false;     
    } else {        
        return true;
    } 
}

function SendServiceMail ($Subject,$MailContent,$MailTo,$AttachmentFile)
{
	/*************************  待改  **************************/
    $mail= new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPAuth = true;
    $mail->Host = "smtp.tfn.net.tw";
    $mail->Port = 25;
    //$mail->CharSet="Big5";
    $mail->CharSet = "utf-8";
    $mail->Encoding = "base64";
    
    $mail->Username = "service@liwasite.com";
    $mail->Password = "";
          
    $mail->From = "service@liwasite.com";
    $mail->FromName = "雲系統管理員";
          
    $mail->Subject = $Subject; //設定郵件標題        
    $mail->Body = $MailContent; //設定郵件內容        
    $mail->IsHTML(true); //設定郵件內容為HTML
    
    $CountMailTo = count($MailTo);
    for ($ii = 0; $ii < $CountMailTo; $ii++){
        $mail->AddAddress("$MailTo[$ii]"); //設定收件者郵件及名稱
    }    
            
    $CountAttachmentFile = count($AttachmentFile);
    for ($ii = 0; $ii < $CountAttachmentFile; $ii++){
        $mail->AddAttachment("$AttachmentFile[$ii]"); //設定附件檔案
    }
    
    if(!$mail->Send()) {        
        return false;     
    } else {        
        return true;
    } 
}

function SendGMail ($Subject,$MailContent,$MailTo,$AttachmentFile,$MailFrom='')
{
	/***************************  待改   ***********************/
    $mail= new PHPMailer(); //建立新物件        
    $mail->IsSMTP(); //設定使用SMTP方式寄信        
    $mail->SMTPAuth = true; //設定SMTP需要驗證        
    $mail->SMTPSecure = "ssl"; // Gmail的SMTP主機需要使用SSL連線   
    $mail->Host = "smtp.gmail.com"; //Gamil的SMTP主機        
    $mail->Port = 465;  //Gamil的SMTP主機的SMTP埠位為465埠。        
    $mail->CharSet = "utf-8"; //設定郵件編碼        
    $mail->Encoding = "base64";
    
    $mail->Username = 'taazestock@gmail.com'; //設定驗證帳號        
    $mail->Password = '2014taazestock'; //設定驗證密碼   
    
    $MailFrom = (!empty($MailFrom)) ? $MailFrom : "service@liwasite.com";
    $mail->From = $MailFrom;
    
    $mail->FromName = "雲系統管理員"; //設定寄件者姓名
          
    $mail->Subject = $Subject; //設定郵件標題        
    $mail->Body = $MailContent; //設定郵件內容        
    $mail->IsHTML(true); //設定郵件內容為HTML
    
    $CountMailTo = count($MailTo);
    for ($ii = 0; $ii < $CountMailTo; $ii++){
        $mail->AddAddress("$MailTo[$ii]"); //設定收件者郵件及名稱
    }    
            
    $CountAttachmentFile = count($AttachmentFile);
    for ($ii = 0; $ii < $CountAttachmentFile; $ii++){
        $mail->AddAttachment("$AttachmentFile[$ii]"); //設定附件檔案
    }
    
    if(!$mail->Send()) {        
        return false;     
    } else {        
        return true;
    } 
}

function str_encrypt($str){
    $privateKey =  base64_decode("emFxIXhzd0BjZGUjdmZyJA==");
    $iv 	=  base64_decode("WkFRIVhTV0BDREUjVkZSJA==");
    
    $strlen = strlen($str);
    //$check_encrypt = substr($str,($strlen - 2),2);
    //if ($check_encrypt == '=='){
    //    return $str;
    //}
    $check_encrypt = substr($str,($strlen - 1),1);
    if ($check_encrypt == '='){
       return $str;
    }
    
    $encrypted = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $privateKey, $str, MCRYPT_MODE_CBC, $iv);
    $encrypted_value = (base64_encode($encrypted));
    
    return $encrypted_value;
}

function str_decrypt($str){
    $privateKey =  base64_decode("emFxIXhzd0BjZGUjdmZyJA==");
    $iv 	=  base64_decode("WkFRIVhTV0BDREUjVkZSJA==");
    
    $strlen = strlen($str);
    //$check_encrypt = substr($str,($strlen - 2),2);
    // if ($check_encrypt <> '=='){
    //     return $str;
    // }
    $check_encrypt = substr($str,($strlen - 1),1);
    if ($check_encrypt <> '='){
        return $str;
    }
    
    $encryptedData = base64_decode($str);
    $decrypted = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $privateKey, $encryptedData, MCRYPT_MODE_CBC, $iv);
    
    return $decrypted;
}

function CheckPOST($arr){
    foreach($arr as $key => $value){
        if (get_magic_quotes_gpc()) {
            $lastname = stripslashes($value);
        }
        $data[$key] = $value;
    }
    return $data;
}


// function UploadMusicFolder($PROD_CAT_ID,$ORG_PROD_ID){
//     if(!is_dir('music/'.substr($ORG_PROD_ID,9,2).'/'.$ORG_PROD_ID)) {
//         mkdir('music/'.substr($ORG_PROD_ID,9,2).'/'.$ORG_PROD_ID, 0777, true);
//         chmod ('music/'.substr($ORG_PROD_ID,9,2).'/'.$ORG_PROD_ID, 0777);
//     }
//     $filePath = 'music/'.substr($ORG_PROD_ID,9,2).'/'.$ORG_PROD_ID.'/';
//     return $filePath;
// }


function getStarSignsName($month, $day) {
    $list=array(
        array('name'=>"摩羯",'min'=>'12-22','max'=>'01-19'),  
        array('name'=>"水瓶",'min'=>'01-20','max'=>'02-18'),
        array('name'=>"雙魚",'min'=>'02-19','max'=>'03-20'),
        array('name'=>"牡羊",'min'=>'03-21','max'=>'04-19'),
        array('name'=>"金牛",'min'=>'04-20','max'=>'05-20'),
        array('name'=>"雙子",'min'=>'05-21','max'=>'06-21'),
        array('name'=>"巨蟹",'min'=>'06-22','max'=>'07-22'),
        array('name'=>"獅子",'min'=>'07-23','max'=>'08-22'),
        array('name'=>"處女",'min'=>'08-23','max'=>'09-22'),
        array('name'=>"天秤",'min'=>'09-23','max'=>'10-23'),
        array('name'=>"天蠍",'min'=>'10-24','max'=>'11-22'),
        array('name'=>"射手",'min'=>'11-23','max'=>'12-21'),
    ); 
    
    $time=strtotime("1970-$month-$day");
    foreach ($list as $row){
        $min=strtotime("1970-".$row['min']);
        $max=strtotime("1970-".$row['max']);
        if($min<=$time && $time<=$max){
            return $row['name'];
        }
    }
    /*other to 摩羯座*/
    return $list[0]['name'];
}

function getScriptFileName(){
    $SCRIPT_NAME = $_SERVER["SCRIPT_NAME"];
    $arr = explode("/", $SCRIPT_NAME);
    $SCRIPT_FILE_NAME = end($arr);
    $SCRIPT_FILE_NAME = str_replace(".php","",$SCRIPT_FILE_NAME);
    
    return $SCRIPT_FILE_NAME;
}

// function sendSMS($sms_text,$mobile_no){
//     $sms_text = iconv("UTF-8","BIG5", $sms_text);
//     $SMS_URL = 'http://bizsms.taiwanmobile.com:18994/send.cgi?username=VCSN044000&password=8233946537&rateplan=A&srcaddr=8702434&dstaddr='.$mobile_no.'&encoding=BIG5&smbody='.$sms_text;
//     $feedback_message = file_get_contents($SMS_URL);
//     $feedback_message = trim($feedback_message);
//     $feedback_msg_arr = explode("\n",$feedback_message);
//     $feedback_msg_status_arr = explode("=",$feedback_msg_arr[2]);
//     $feedback_msg_status = $feedback_msg_status_arr[1];
//     return $feedback_msg_status;
// }
?>