<?php
header("Access-Control-Allow-Origin: *");
include_once("./util.php");
include_once("./class/Mysql.class.php");
date_default_timezone_set("Asia/Taipei");

if ($_GET)
{
	$userID = $_GET['userID'];
	$mainID = isset($_GET['mainID'])?$_GET['mainID']:"";

	$arrjson = array();
	$msg = '';

	$db = new MySQLDB('liwa05', 'utf8mb4');
	$SQL = "select A.username, A.nickname, A.gender, A.usermail, replace(A.birthday, '/','-') as birthday, A.zip, A.addr, A.phone, A.mobile, A.originSiteID as siteID, A.picpath, A.iconPath, A.roles, A.iSites, A.iStatus, B.uGroupID, B.uGroupName, B.iAuth, B.isTop from W02_M A, 002_M B where A.userID = B.mainID and A.userID = '".$mainID."'";

	$result = $db->query($SQL);
	$liwaData = $db->fetchDataArray($result);
	$liwaData = replaceNulltoEmptyStr($liwaData);

	echo json_encode(array('arrSQL'=>$liwaData));
	
	$db->close();
}
?>