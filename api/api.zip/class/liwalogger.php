<?php
include_once('define.php');
include(ROOT_DIR.'/api/sys/util.php');

class liwaLogger {
    private $siteID;
    private $DATABASE_LOGGER_API_URL = 'http://localhost/api/sys/sys_addLog_v2.php';
    private $START_MESSAGE = '** LOG START  **';
    private $END_MESSAGE = '** LOG END **';
    private $END_STATUS = 'S';
    private $BEGIN_STATUS = 'I';
    private $logId;
    private $logName;  
    private $logPath;
    private $scriptName;
    private $hostIp;
    private $userID;
    private $userNM;
    private $handle;  

    private $logToFile;
    private $logToConsole;
    private $logToDatabase;
 
    public function __construct($siteID = 'liwa05', $logName = null, $logPath = null, $scriptName = null, $logToFile = true, $logToDatabase = true, $logToConsole = false, $userID='', $userNM='') {
        $this->siteID = $siteID;
        $this->logId = getUUID();       
        $this->logToFile = $logToFile;
        $this->logToConsole = $logToConsole;
        $this->logToDatabase = $logToDatabase;
        $this->logName = $logName;
        $this->logPath = $logPath;
        $this->scriptName = $scriptName;
        $this->userID = $userID;
        $this->userNM = $userNM;

        $this->hostIp = getHostByName(getHostName());

        $this->setFileStructure();

        $this->logWrite($this->START_MESSAGE, $this->BEGIN_STATUS);       
   }
 
    function __destruct() {
       if ($this->logToFile) {
           fclose($this->handle);
       }

        $this->logWrite($this->END_MESSAGE, $this->END_STATUS);
    }
    
    // Creating the file in the path specified    
    private function setFileStructure() {
        if (!$this->logToFile) {
            return;
        }

        if (is_null($this->logName)) {
            $this->logName = "Log.".date("YmdHis").".log";
        }

        if (is_null($this->logPath)) {
            $this->logPath = '';
        }

        $this->logOpen();
    }

    // Open Logfile
    private function logOpen(){  
        if (!file_exists($this->logPath)) {
            mkdir($this->logPath, 0777, true);
        }
        
        $this->handle = fopen($this->logPath . $this->logName , 'a+') or exit("Can't open " . $this->logPath . $this->logName );
  	} 

    private function logToFile($message, $logType, $time) {
        fwrite($this->handle, $time . " " . $message . "\n"); //Output to logfile
    }
 
    private function logToConsole($message, $logType, $time) {
        echo $time . " " . $message . PHP_EOL;
    }

    private function logToDatabase($message, $logType, $time) {
        $ch = curl_init();
        $body = array(
                'siteID' => $this->siteID,
                'log_ID' => $this->logId,
                'hostIP' => $this->hostIp,
                'fileNM' => $this->logName, 
                'progNM' => $this->scriptName, 
                'logPath' => $this->logPath,
                'log' => addslashes($message), 
                'STATUS' => $logType,
                'CRT_USERID' => $this->userID,
                'CRT_USERNM' => $this->userNM
            );

        curl_setopt($ch, CURLOPT_URL, $this->DATABASE_LOGGER_API_URL); 
        curl_setopt($ch, CURLOPT_POST, true); 
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
    }

  	//Write Message to Logfile
    public function logWrite($message, $logType = 'Q'){  
        $time = date('Y-m-d @ H:i:s -'); //Grab Time
    
        if($this->logToFile) {
            $this->logToFile($message, $logType, $time);
        }

        if($this->logToDatabase) {
            $this->LogToDatabase($message, $logType, $time);
        }

        if($this->logToConsole) {
            $this->logToConsole($message, $logType, $time);
        }
  	}

  	//Clear Logfile
  	private function logClear(){
        ftruncate($this->handle, 0);
    }

    private function getHostIp() {
        return $this->hostIp;
    }
}
